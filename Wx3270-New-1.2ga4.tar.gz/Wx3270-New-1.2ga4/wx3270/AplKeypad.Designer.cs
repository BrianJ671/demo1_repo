﻿namespace Wx3270
{
    partial class AplKeypad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AplKeypad));
            this.keypadOuterPanel = new System.Windows.Forms.Panel();
            this.keyboardPanel = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.minusButton = new Wx3270.NoSelectButton();
            this.panel47 = new System.Windows.Forms.Panel();
            this.slashButton = new Wx3270.NoSelectButton();
            this.panel46 = new System.Windows.Forms.Panel();
            this.periodButton = new Wx3270.NoSelectButton();
            this.panel45 = new System.Windows.Forms.Panel();
            this.commaButton = new Wx3270.NoSelectButton();
            this.panel11 = new System.Windows.Forms.Panel();
            this.zeroButton = new Wx3270.NoSelectButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.fourButton = new Wx3270.NoSelectButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.nineButton = new Wx3270.NoSelectButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.sevenButton = new Wx3270.NoSelectButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.oneButton = new Wx3270.NoSelectButton();
            this.panel44 = new System.Windows.Forms.Panel();
            this.mButton = new Wx3270.NoSelectButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.sixButton = new Wx3270.NoSelectButton();
            this.panel43 = new System.Windows.Forms.Panel();
            this.nButton = new Wx3270.NoSelectButton();
            this.panel42 = new System.Windows.Forms.Panel();
            this.bButton = new Wx3270.NoSelectButton();
            this.panel41 = new System.Windows.Forms.Panel();
            this.vButton = new Wx3270.NoSelectButton();
            this.panel40 = new System.Windows.Forms.Panel();
            this.cButton = new Wx3270.NoSelectButton();
            this.panel39 = new System.Windows.Forms.Panel();
            this.xButton = new Wx3270.NoSelectButton();
            this.panel38 = new System.Windows.Forms.Panel();
            this.zButton = new Wx3270.NoSelectButton();
            this.panel37 = new System.Windows.Forms.Panel();
            this.apostropheButton = new Wx3270.NoSelectButton();
            this.panel36 = new System.Windows.Forms.Panel();
            this.semicolonButton = new Wx3270.NoSelectButton();
            this.panel35 = new System.Windows.Forms.Panel();
            this.lButton = new Wx3270.NoSelectButton();
            this.panel34 = new System.Windows.Forms.Panel();
            this.kButton = new Wx3270.NoSelectButton();
            this.panel33 = new System.Windows.Forms.Panel();
            this.jButton = new Wx3270.NoSelectButton();
            this.panel32 = new System.Windows.Forms.Panel();
            this.hButton = new Wx3270.NoSelectButton();
            this.panel31 = new System.Windows.Forms.Panel();
            this.gButton = new Wx3270.NoSelectButton();
            this.panel30 = new System.Windows.Forms.Panel();
            this.fButton = new Wx3270.NoSelectButton();
            this.panel29 = new System.Windows.Forms.Panel();
            this.dButton = new Wx3270.NoSelectButton();
            this.panel28 = new System.Windows.Forms.Panel();
            this.sButton = new Wx3270.NoSelectButton();
            this.panel14 = new System.Windows.Forms.Panel();
            this.aButton = new Wx3270.NoSelectButton();
            this.panel27 = new System.Windows.Forms.Panel();
            this.backslashButton = new Wx3270.NoSelectButton();
            this.panel26 = new System.Windows.Forms.Panel();
            this.rightBracketButton = new Wx3270.NoSelectButton();
            this.panel25 = new System.Windows.Forms.Panel();
            this.leftBracketButton = new Wx3270.NoSelectButton();
            this.panel24 = new System.Windows.Forms.Panel();
            this.pButton = new Wx3270.NoSelectButton();
            this.panel23 = new System.Windows.Forms.Panel();
            this.oButton = new Wx3270.NoSelectButton();
            this.panel22 = new System.Windows.Forms.Panel();
            this.iButton = new Wx3270.NoSelectButton();
            this.panel21 = new System.Windows.Forms.Panel();
            this.uButton = new Wx3270.NoSelectButton();
            this.panel20 = new System.Windows.Forms.Panel();
            this.yButton = new Wx3270.NoSelectButton();
            this.panel19 = new System.Windows.Forms.Panel();
            this.tButton = new Wx3270.NoSelectButton();
            this.panel18 = new System.Windows.Forms.Panel();
            this.rButton = new Wx3270.NoSelectButton();
            this.panel17 = new System.Windows.Forms.Panel();
            this.eButton = new Wx3270.NoSelectButton();
            this.panel16 = new System.Windows.Forms.Panel();
            this.wButton = new Wx3270.NoSelectButton();
            this.panel15 = new System.Windows.Forms.Panel();
            this.qButton = new Wx3270.NoSelectButton();
            this.panel13 = new System.Windows.Forms.Panel();
            this.equalsButton = new Wx3270.NoSelectButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.eightButton = new Wx3270.NoSelectButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.fiveButton = new Wx3270.NoSelectButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.threeButton = new Wx3270.NoSelectButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.twoButton = new Wx3270.NoSelectButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.graveButton = new Wx3270.NoSelectButton();
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.helpPictureBox = new System.Windows.Forms.PictureBox();
            this.helpContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.displayHelpInBrowserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startTourToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.keypadOuterPanel.SuspendLayout();
            this.keyboardPanel.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.helpPictureBox)).BeginInit();
            this.helpContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // keypadOuterPanel
            // 
            this.keypadOuterPanel.AutoSize = true;
            this.keypadOuterPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.keypadOuterPanel.Controls.Add(this.keyboardPanel);
            this.keypadOuterPanel.Location = new System.Drawing.Point(0, 0);
            this.keypadOuterPanel.Margin = new System.Windows.Forms.Padding(0);
            this.keypadOuterPanel.Name = "keypadOuterPanel";
            this.keypadOuterPanel.Size = new System.Drawing.Size(928, 236);
            this.keypadOuterPanel.TabIndex = 37;
            // 
            // keyboardPanel
            // 
            this.keyboardPanel.AutoSize = true;
            this.keyboardPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.keyboardPanel.BackColor = System.Drawing.Color.Black;
            this.keyboardPanel.Controls.Add(this.panel12);
            this.keyboardPanel.Controls.Add(this.panel47);
            this.keyboardPanel.Controls.Add(this.panel46);
            this.keyboardPanel.Controls.Add(this.panel45);
            this.keyboardPanel.Controls.Add(this.panel11);
            this.keyboardPanel.Controls.Add(this.panel5);
            this.keyboardPanel.Controls.Add(this.panel10);
            this.keyboardPanel.Controls.Add(this.panel8);
            this.keyboardPanel.Controls.Add(this.panel3);
            this.keyboardPanel.Controls.Add(this.panel44);
            this.keyboardPanel.Controls.Add(this.panel7);
            this.keyboardPanel.Controls.Add(this.panel43);
            this.keyboardPanel.Controls.Add(this.panel42);
            this.keyboardPanel.Controls.Add(this.panel41);
            this.keyboardPanel.Controls.Add(this.panel40);
            this.keyboardPanel.Controls.Add(this.panel39);
            this.keyboardPanel.Controls.Add(this.panel38);
            this.keyboardPanel.Controls.Add(this.panel37);
            this.keyboardPanel.Controls.Add(this.panel36);
            this.keyboardPanel.Controls.Add(this.panel35);
            this.keyboardPanel.Controls.Add(this.panel34);
            this.keyboardPanel.Controls.Add(this.panel33);
            this.keyboardPanel.Controls.Add(this.panel32);
            this.keyboardPanel.Controls.Add(this.panel31);
            this.keyboardPanel.Controls.Add(this.panel30);
            this.keyboardPanel.Controls.Add(this.panel29);
            this.keyboardPanel.Controls.Add(this.panel28);
            this.keyboardPanel.Controls.Add(this.panel14);
            this.keyboardPanel.Controls.Add(this.panel27);
            this.keyboardPanel.Controls.Add(this.panel26);
            this.keyboardPanel.Controls.Add(this.panel25);
            this.keyboardPanel.Controls.Add(this.panel24);
            this.keyboardPanel.Controls.Add(this.panel23);
            this.keyboardPanel.Controls.Add(this.panel22);
            this.keyboardPanel.Controls.Add(this.panel21);
            this.keyboardPanel.Controls.Add(this.panel20);
            this.keyboardPanel.Controls.Add(this.panel19);
            this.keyboardPanel.Controls.Add(this.panel18);
            this.keyboardPanel.Controls.Add(this.panel17);
            this.keyboardPanel.Controls.Add(this.panel16);
            this.keyboardPanel.Controls.Add(this.panel15);
            this.keyboardPanel.Controls.Add(this.panel13);
            this.keyboardPanel.Controls.Add(this.panel9);
            this.keyboardPanel.Controls.Add(this.panel6);
            this.keyboardPanel.Controls.Add(this.panel1);
            this.keyboardPanel.Controls.Add(this.panel4);
            this.keyboardPanel.Controls.Add(this.panel2);
            this.keyboardPanel.Location = new System.Drawing.Point(0, 0);
            this.keyboardPanel.Margin = new System.Windows.Forms.Padding(0);
            this.keyboardPanel.Name = "keyboardPanel";
            this.keyboardPanel.Size = new System.Drawing.Size(928, 236);
            this.keyboardPanel.TabIndex = 38;
            this.keyboardPanel.Tag = "<nowalk>";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.Controls.Add(this.minusButton);
            this.panel12.Location = new System.Drawing.Point(704, 0);
            this.panel12.Margin = new System.Windows.Forms.Padding(0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(64, 59);
            this.panel12.TabIndex = 43;
            // 
            // minusButton
            // 
            this.minusButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.minusButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.minusButton.FlatAppearance.BorderSize = 0;
            this.minusButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.minusButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.minusButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minusButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minusButton.ForeColor = System.Drawing.Color.DarkGray;
            this.minusButton.Location = new System.Drawing.Point(0, 0);
            this.minusButton.Margin = new System.Windows.Forms.Padding(0);
            this.minusButton.Name = "minusButton";
            this.minusButton.Size = new System.Drawing.Size(64, 59);
            this.minusButton.TabIndex = 0;
            this.minusButton.TabStop = false;
            this.minusButton.Tag = "";
            this.minusButton.Text = "_\r\n-";
            this.minusButton.UseVisualStyleBackColor = true;
            this.minusButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.minusButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.Black;
            this.panel47.Controls.Add(this.slashButton);
            this.panel47.Location = new System.Drawing.Point(736, 177);
            this.panel47.Margin = new System.Windows.Forms.Padding(0);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(64, 59);
            this.panel47.TabIndex = 78;
            // 
            // slashButton
            // 
            this.slashButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.slashButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.slashButton.FlatAppearance.BorderSize = 0;
            this.slashButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.slashButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.slashButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.slashButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slashButton.ForeColor = System.Drawing.Color.DarkGray;
            this.slashButton.Location = new System.Drawing.Point(0, 0);
            this.slashButton.Margin = new System.Windows.Forms.Padding(0);
            this.slashButton.Name = "slashButton";
            this.slashButton.Size = new System.Drawing.Size(64, 59);
            this.slashButton.TabIndex = 0;
            this.slashButton.TabStop = false;
            this.slashButton.Tag = "";
            this.slashButton.Text = "?\r\n/";
            this.slashButton.UseVisualStyleBackColor = true;
            this.slashButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.slashButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.Black;
            this.panel46.Controls.Add(this.periodButton);
            this.panel46.Location = new System.Drawing.Point(672, 177);
            this.panel46.Margin = new System.Windows.Forms.Padding(0);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(64, 59);
            this.panel46.TabIndex = 77;
            // 
            // periodButton
            // 
            this.periodButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.periodButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.periodButton.FlatAppearance.BorderSize = 0;
            this.periodButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.periodButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.periodButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.periodButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodButton.ForeColor = System.Drawing.Color.DarkGray;
            this.periodButton.Location = new System.Drawing.Point(0, 0);
            this.periodButton.Margin = new System.Windows.Forms.Padding(0);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(64, 59);
            this.periodButton.TabIndex = 0;
            this.periodButton.TabStop = false;
            this.periodButton.Tag = "";
            this.periodButton.Text = ">\r\n.";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.periodButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.Black;
            this.panel45.Controls.Add(this.commaButton);
            this.panel45.Location = new System.Drawing.Point(608, 177);
            this.panel45.Margin = new System.Windows.Forms.Padding(0);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(64, 59);
            this.panel45.TabIndex = 76;
            // 
            // commaButton
            // 
            this.commaButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.commaButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.commaButton.FlatAppearance.BorderSize = 0;
            this.commaButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.commaButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.commaButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.commaButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commaButton.ForeColor = System.Drawing.Color.DarkGray;
            this.commaButton.Location = new System.Drawing.Point(0, 0);
            this.commaButton.Margin = new System.Windows.Forms.Padding(0);
            this.commaButton.Name = "commaButton";
            this.commaButton.Size = new System.Drawing.Size(64, 59);
            this.commaButton.TabIndex = 0;
            this.commaButton.TabStop = false;
            this.commaButton.Tag = "";
            this.commaButton.Text = "<\r\n,";
            this.commaButton.UseVisualStyleBackColor = true;
            this.commaButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.commaButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Controls.Add(this.zeroButton);
            this.panel11.Location = new System.Drawing.Point(640, 0);
            this.panel11.Margin = new System.Windows.Forms.Padding(0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(64, 59);
            this.panel11.TabIndex = 43;
            // 
            // zeroButton
            // 
            this.zeroButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.zeroButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.zeroButton.FlatAppearance.BorderSize = 0;
            this.zeroButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.zeroButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.zeroButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.zeroButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zeroButton.ForeColor = System.Drawing.Color.DarkGray;
            this.zeroButton.Location = new System.Drawing.Point(0, 0);
            this.zeroButton.Margin = new System.Windows.Forms.Padding(0);
            this.zeroButton.Name = "zeroButton";
            this.zeroButton.Size = new System.Drawing.Size(64, 59);
            this.zeroButton.TabIndex = 0;
            this.zeroButton.TabStop = false;
            this.zeroButton.Tag = "";
            this.zeroButton.Text = ")\r\n0";
            this.zeroButton.UseVisualStyleBackColor = true;
            this.zeroButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.zeroButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Controls.Add(this.fourButton);
            this.panel5.Location = new System.Drawing.Point(256, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(64, 59);
            this.panel5.TabIndex = 41;
            // 
            // fourButton
            // 
            this.fourButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.fourButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.fourButton.FlatAppearance.BorderSize = 0;
            this.fourButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.fourButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.fourButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fourButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fourButton.ForeColor = System.Drawing.Color.DarkGray;
            this.fourButton.Location = new System.Drawing.Point(0, 0);
            this.fourButton.Margin = new System.Windows.Forms.Padding(0);
            this.fourButton.Name = "fourButton";
            this.fourButton.Size = new System.Drawing.Size(64, 59);
            this.fourButton.TabIndex = 0;
            this.fourButton.TabStop = false;
            this.fourButton.Tag = "";
            this.fourButton.Text = "$\r\n4";
            this.fourButton.UseVisualStyleBackColor = true;
            this.fourButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.fourButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Controls.Add(this.nineButton);
            this.panel10.Location = new System.Drawing.Point(576, 0);
            this.panel10.Margin = new System.Windows.Forms.Padding(0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(64, 59);
            this.panel10.TabIndex = 43;
            // 
            // nineButton
            // 
            this.nineButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.nineButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.nineButton.FlatAppearance.BorderSize = 0;
            this.nineButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.nineButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.nineButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nineButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nineButton.ForeColor = System.Drawing.Color.DarkGray;
            this.nineButton.Location = new System.Drawing.Point(0, 0);
            this.nineButton.Margin = new System.Windows.Forms.Padding(0);
            this.nineButton.Name = "nineButton";
            this.nineButton.Size = new System.Drawing.Size(64, 59);
            this.nineButton.TabIndex = 0;
            this.nineButton.TabStop = false;
            this.nineButton.Tag = "";
            this.nineButton.Text = "(\r\n9";
            this.nineButton.UseVisualStyleBackColor = true;
            this.nineButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.nineButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Controls.Add(this.sevenButton);
            this.panel8.Location = new System.Drawing.Point(448, 0);
            this.panel8.Margin = new System.Windows.Forms.Padding(0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(64, 59);
            this.panel8.TabIndex = 42;
            // 
            // sevenButton
            // 
            this.sevenButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.sevenButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.sevenButton.FlatAppearance.BorderSize = 0;
            this.sevenButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.sevenButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.sevenButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sevenButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sevenButton.ForeColor = System.Drawing.Color.DarkGray;
            this.sevenButton.Location = new System.Drawing.Point(0, 0);
            this.sevenButton.Margin = new System.Windows.Forms.Padding(0);
            this.sevenButton.Name = "sevenButton";
            this.sevenButton.Size = new System.Drawing.Size(64, 59);
            this.sevenButton.TabIndex = 0;
            this.sevenButton.TabStop = false;
            this.sevenButton.Tag = "";
            this.sevenButton.Text = "&&\r\n7";
            this.sevenButton.UseVisualStyleBackColor = true;
            this.sevenButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.sevenButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Controls.Add(this.oneButton);
            this.panel3.Location = new System.Drawing.Point(64, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(64, 59);
            this.panel3.TabIndex = 39;
            // 
            // oneButton
            // 
            this.oneButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.oneButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.oneButton.FlatAppearance.BorderSize = 0;
            this.oneButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.oneButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.oneButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.oneButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneButton.ForeColor = System.Drawing.Color.DarkGray;
            this.oneButton.Location = new System.Drawing.Point(0, 0);
            this.oneButton.Margin = new System.Windows.Forms.Padding(0);
            this.oneButton.Name = "oneButton";
            this.oneButton.Size = new System.Drawing.Size(64, 59);
            this.oneButton.TabIndex = 0;
            this.oneButton.TabStop = false;
            this.oneButton.Tag = "";
            this.oneButton.Text = "!\r\n1";
            this.oneButton.UseVisualStyleBackColor = true;
            this.oneButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.oneButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.Black;
            this.panel44.Controls.Add(this.mButton);
            this.panel44.Location = new System.Drawing.Point(544, 177);
            this.panel44.Margin = new System.Windows.Forms.Padding(0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(64, 59);
            this.panel44.TabIndex = 75;
            // 
            // mButton
            // 
            this.mButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.mButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mButton.FlatAppearance.BorderSize = 0;
            this.mButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.mButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.mButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mButton.ForeColor = System.Drawing.Color.DarkGray;
            this.mButton.Location = new System.Drawing.Point(0, 0);
            this.mButton.Margin = new System.Windows.Forms.Padding(0);
            this.mButton.Name = "mButton";
            this.mButton.Size = new System.Drawing.Size(64, 59);
            this.mButton.TabIndex = 0;
            this.mButton.TabStop = false;
            this.mButton.Tag = "";
            this.mButton.Text = "M";
            this.mButton.UseVisualStyleBackColor = true;
            this.mButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.mButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Controls.Add(this.sixButton);
            this.panel7.Location = new System.Drawing.Point(384, 0);
            this.panel7.Margin = new System.Windows.Forms.Padding(0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(64, 59);
            this.panel7.TabIndex = 42;
            // 
            // sixButton
            // 
            this.sixButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.sixButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.sixButton.FlatAppearance.BorderSize = 0;
            this.sixButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.sixButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.sixButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sixButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sixButton.ForeColor = System.Drawing.Color.DarkGray;
            this.sixButton.Location = new System.Drawing.Point(0, 0);
            this.sixButton.Margin = new System.Windows.Forms.Padding(0);
            this.sixButton.Name = "sixButton";
            this.sixButton.Size = new System.Drawing.Size(64, 59);
            this.sixButton.TabIndex = 0;
            this.sixButton.TabStop = false;
            this.sixButton.Tag = "";
            this.sixButton.Text = "^\r\n6";
            this.sixButton.UseVisualStyleBackColor = true;
            this.sixButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.sixButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.Black;
            this.panel43.Controls.Add(this.nButton);
            this.panel43.Location = new System.Drawing.Point(480, 177);
            this.panel43.Margin = new System.Windows.Forms.Padding(0);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(64, 59);
            this.panel43.TabIndex = 74;
            // 
            // nButton
            // 
            this.nButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.nButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.nButton.FlatAppearance.BorderSize = 0;
            this.nButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.nButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.nButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nButton.ForeColor = System.Drawing.Color.DarkGray;
            this.nButton.Location = new System.Drawing.Point(0, 0);
            this.nButton.Margin = new System.Windows.Forms.Padding(0);
            this.nButton.Name = "nButton";
            this.nButton.Size = new System.Drawing.Size(64, 59);
            this.nButton.TabIndex = 0;
            this.nButton.TabStop = false;
            this.nButton.Tag = "";
            this.nButton.Text = "N";
            this.nButton.UseVisualStyleBackColor = true;
            this.nButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.nButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.Black;
            this.panel42.Controls.Add(this.bButton);
            this.panel42.Location = new System.Drawing.Point(416, 177);
            this.panel42.Margin = new System.Windows.Forms.Padding(0);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(64, 59);
            this.panel42.TabIndex = 73;
            // 
            // bButton
            // 
            this.bButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.bButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.bButton.FlatAppearance.BorderSize = 0;
            this.bButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.bButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.bButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bButton.ForeColor = System.Drawing.Color.DarkGray;
            this.bButton.Location = new System.Drawing.Point(0, 0);
            this.bButton.Margin = new System.Windows.Forms.Padding(0);
            this.bButton.Name = "bButton";
            this.bButton.Size = new System.Drawing.Size(64, 59);
            this.bButton.TabIndex = 0;
            this.bButton.TabStop = false;
            this.bButton.Tag = "";
            this.bButton.Text = "B";
            this.bButton.UseVisualStyleBackColor = true;
            this.bButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.bButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.Black;
            this.panel41.Controls.Add(this.vButton);
            this.panel41.Location = new System.Drawing.Point(352, 177);
            this.panel41.Margin = new System.Windows.Forms.Padding(0);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(64, 59);
            this.panel41.TabIndex = 72;
            // 
            // vButton
            // 
            this.vButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.vButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.vButton.FlatAppearance.BorderSize = 0;
            this.vButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.vButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.vButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vButton.ForeColor = System.Drawing.Color.DarkGray;
            this.vButton.Location = new System.Drawing.Point(0, 0);
            this.vButton.Margin = new System.Windows.Forms.Padding(0);
            this.vButton.Name = "vButton";
            this.vButton.Size = new System.Drawing.Size(64, 59);
            this.vButton.TabIndex = 0;
            this.vButton.TabStop = false;
            this.vButton.Tag = "";
            this.vButton.Text = "V";
            this.vButton.UseVisualStyleBackColor = true;
            this.vButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.vButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.Black;
            this.panel40.Controls.Add(this.cButton);
            this.panel40.Location = new System.Drawing.Point(288, 177);
            this.panel40.Margin = new System.Windows.Forms.Padding(0);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(64, 59);
            this.panel40.TabIndex = 71;
            // 
            // cButton
            // 
            this.cButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.cButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cButton.FlatAppearance.BorderSize = 0;
            this.cButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.cButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.cButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cButton.ForeColor = System.Drawing.Color.DarkGray;
            this.cButton.Location = new System.Drawing.Point(0, 0);
            this.cButton.Margin = new System.Windows.Forms.Padding(0);
            this.cButton.Name = "cButton";
            this.cButton.Size = new System.Drawing.Size(64, 59);
            this.cButton.TabIndex = 0;
            this.cButton.TabStop = false;
            this.cButton.Tag = "";
            this.cButton.Text = "C";
            this.cButton.UseVisualStyleBackColor = true;
            this.cButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.cButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.Black;
            this.panel39.Controls.Add(this.xButton);
            this.panel39.Location = new System.Drawing.Point(224, 177);
            this.panel39.Margin = new System.Windows.Forms.Padding(0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(64, 59);
            this.panel39.TabIndex = 70;
            // 
            // xButton
            // 
            this.xButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.xButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.xButton.FlatAppearance.BorderSize = 0;
            this.xButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.xButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.xButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xButton.ForeColor = System.Drawing.Color.DarkGray;
            this.xButton.Location = new System.Drawing.Point(0, 0);
            this.xButton.Margin = new System.Windows.Forms.Padding(0);
            this.xButton.Name = "xButton";
            this.xButton.Size = new System.Drawing.Size(64, 59);
            this.xButton.TabIndex = 0;
            this.xButton.TabStop = false;
            this.xButton.Tag = "";
            this.xButton.Text = "X";
            this.xButton.UseVisualStyleBackColor = true;
            this.xButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.xButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.Black;
            this.panel38.Controls.Add(this.zButton);
            this.panel38.Location = new System.Drawing.Point(160, 177);
            this.panel38.Margin = new System.Windows.Forms.Padding(0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(64, 59);
            this.panel38.TabIndex = 69;
            // 
            // zButton
            // 
            this.zButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.zButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.zButton.FlatAppearance.BorderSize = 0;
            this.zButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.zButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.zButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.zButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zButton.ForeColor = System.Drawing.Color.DarkGray;
            this.zButton.Location = new System.Drawing.Point(0, 0);
            this.zButton.Margin = new System.Windows.Forms.Padding(0);
            this.zButton.Name = "zButton";
            this.zButton.Size = new System.Drawing.Size(64, 59);
            this.zButton.TabIndex = 0;
            this.zButton.TabStop = false;
            this.zButton.Tag = "";
            this.zButton.Text = "Z";
            this.zButton.UseVisualStyleBackColor = true;
            this.zButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.zButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.Black;
            this.panel37.Controls.Add(this.apostropheButton);
            this.panel37.Location = new System.Drawing.Point(768, 118);
            this.panel37.Margin = new System.Windows.Forms.Padding(0);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(64, 59);
            this.panel37.TabIndex = 68;
            // 
            // apostropheButton
            // 
            this.apostropheButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.apostropheButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.apostropheButton.FlatAppearance.BorderSize = 0;
            this.apostropheButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.apostropheButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.apostropheButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.apostropheButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apostropheButton.ForeColor = System.Drawing.Color.DarkGray;
            this.apostropheButton.Location = new System.Drawing.Point(0, 0);
            this.apostropheButton.Margin = new System.Windows.Forms.Padding(0);
            this.apostropheButton.Name = "apostropheButton";
            this.apostropheButton.Size = new System.Drawing.Size(64, 59);
            this.apostropheButton.TabIndex = 0;
            this.apostropheButton.TabStop = false;
            this.apostropheButton.Tag = "";
            this.apostropheButton.Text = "\"\r\n\'";
            this.apostropheButton.UseVisualStyleBackColor = true;
            this.apostropheButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.apostropheButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.Black;
            this.panel36.Controls.Add(this.semicolonButton);
            this.panel36.Location = new System.Drawing.Point(704, 118);
            this.panel36.Margin = new System.Windows.Forms.Padding(0);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(64, 59);
            this.panel36.TabIndex = 67;
            // 
            // semicolonButton
            // 
            this.semicolonButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.semicolonButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.semicolonButton.FlatAppearance.BorderSize = 0;
            this.semicolonButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.semicolonButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.semicolonButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.semicolonButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.semicolonButton.ForeColor = System.Drawing.Color.DarkGray;
            this.semicolonButton.Location = new System.Drawing.Point(0, 0);
            this.semicolonButton.Margin = new System.Windows.Forms.Padding(0);
            this.semicolonButton.Name = "semicolonButton";
            this.semicolonButton.Size = new System.Drawing.Size(64, 59);
            this.semicolonButton.TabIndex = 0;
            this.semicolonButton.TabStop = false;
            this.semicolonButton.Tag = "";
            this.semicolonButton.Text = ":\r\n;";
            this.semicolonButton.UseVisualStyleBackColor = true;
            this.semicolonButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.semicolonButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.Black;
            this.panel35.Controls.Add(this.lButton);
            this.panel35.Location = new System.Drawing.Point(640, 118);
            this.panel35.Margin = new System.Windows.Forms.Padding(0);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(64, 59);
            this.panel35.TabIndex = 66;
            // 
            // lButton
            // 
            this.lButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.lButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.lButton.FlatAppearance.BorderSize = 0;
            this.lButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.lButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.lButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lButton.ForeColor = System.Drawing.Color.DarkGray;
            this.lButton.Location = new System.Drawing.Point(0, 0);
            this.lButton.Margin = new System.Windows.Forms.Padding(0);
            this.lButton.Name = "lButton";
            this.lButton.Size = new System.Drawing.Size(64, 59);
            this.lButton.TabIndex = 0;
            this.lButton.TabStop = false;
            this.lButton.Tag = "";
            this.lButton.Text = "L";
            this.lButton.UseVisualStyleBackColor = true;
            this.lButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.lButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.Black;
            this.panel34.Controls.Add(this.kButton);
            this.panel34.Location = new System.Drawing.Point(576, 118);
            this.panel34.Margin = new System.Windows.Forms.Padding(0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(64, 59);
            this.panel34.TabIndex = 65;
            // 
            // kButton
            // 
            this.kButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.kButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.kButton.FlatAppearance.BorderSize = 0;
            this.kButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.kButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.kButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.kButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kButton.ForeColor = System.Drawing.Color.DarkGray;
            this.kButton.Location = new System.Drawing.Point(0, 0);
            this.kButton.Margin = new System.Windows.Forms.Padding(0);
            this.kButton.Name = "kButton";
            this.kButton.Size = new System.Drawing.Size(64, 59);
            this.kButton.TabIndex = 0;
            this.kButton.TabStop = false;
            this.kButton.Tag = "";
            this.kButton.Text = "K";
            this.kButton.UseVisualStyleBackColor = true;
            this.kButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.kButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.Black;
            this.panel33.Controls.Add(this.jButton);
            this.panel33.Location = new System.Drawing.Point(512, 118);
            this.panel33.Margin = new System.Windows.Forms.Padding(0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(64, 59);
            this.panel33.TabIndex = 64;
            // 
            // jButton
            // 
            this.jButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.jButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.jButton.FlatAppearance.BorderSize = 0;
            this.jButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.jButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.jButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton.ForeColor = System.Drawing.Color.DarkGray;
            this.jButton.Location = new System.Drawing.Point(0, 0);
            this.jButton.Margin = new System.Windows.Forms.Padding(0);
            this.jButton.Name = "jButton";
            this.jButton.Size = new System.Drawing.Size(64, 59);
            this.jButton.TabIndex = 0;
            this.jButton.TabStop = false;
            this.jButton.Tag = "";
            this.jButton.Text = "J";
            this.jButton.UseVisualStyleBackColor = true;
            this.jButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.jButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.Black;
            this.panel32.Controls.Add(this.hButton);
            this.panel32.Location = new System.Drawing.Point(448, 118);
            this.panel32.Margin = new System.Windows.Forms.Padding(0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(64, 59);
            this.panel32.TabIndex = 63;
            // 
            // hButton
            // 
            this.hButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.hButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.hButton.FlatAppearance.BorderSize = 0;
            this.hButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.hButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.hButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hButton.ForeColor = System.Drawing.Color.DarkGray;
            this.hButton.Location = new System.Drawing.Point(0, 0);
            this.hButton.Margin = new System.Windows.Forms.Padding(0);
            this.hButton.Name = "hButton";
            this.hButton.Size = new System.Drawing.Size(64, 59);
            this.hButton.TabIndex = 0;
            this.hButton.TabStop = false;
            this.hButton.Tag = "";
            this.hButton.Text = "H";
            this.hButton.UseVisualStyleBackColor = true;
            this.hButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.hButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.Black;
            this.panel31.Controls.Add(this.gButton);
            this.panel31.Location = new System.Drawing.Point(384, 118);
            this.panel31.Margin = new System.Windows.Forms.Padding(0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(64, 59);
            this.panel31.TabIndex = 62;
            // 
            // gButton
            // 
            this.gButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.gButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.gButton.FlatAppearance.BorderSize = 0;
            this.gButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.gButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.gButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gButton.ForeColor = System.Drawing.Color.DarkGray;
            this.gButton.Location = new System.Drawing.Point(0, 0);
            this.gButton.Margin = new System.Windows.Forms.Padding(0);
            this.gButton.Name = "gButton";
            this.gButton.Size = new System.Drawing.Size(64, 59);
            this.gButton.TabIndex = 0;
            this.gButton.TabStop = false;
            this.gButton.Tag = "";
            this.gButton.Text = "G";
            this.gButton.UseVisualStyleBackColor = true;
            this.gButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.gButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.Black;
            this.panel30.Controls.Add(this.fButton);
            this.panel30.Location = new System.Drawing.Point(320, 118);
            this.panel30.Margin = new System.Windows.Forms.Padding(0);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(64, 59);
            this.panel30.TabIndex = 61;
            // 
            // fButton
            // 
            this.fButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.fButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.fButton.FlatAppearance.BorderSize = 0;
            this.fButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.fButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.fButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fButton.ForeColor = System.Drawing.Color.DarkGray;
            this.fButton.Location = new System.Drawing.Point(0, 0);
            this.fButton.Margin = new System.Windows.Forms.Padding(0);
            this.fButton.Name = "fButton";
            this.fButton.Size = new System.Drawing.Size(64, 59);
            this.fButton.TabIndex = 0;
            this.fButton.TabStop = false;
            this.fButton.Tag = "";
            this.fButton.Text = "F";
            this.fButton.UseVisualStyleBackColor = true;
            this.fButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.fButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.Black;
            this.panel29.Controls.Add(this.dButton);
            this.panel29.Location = new System.Drawing.Point(256, 118);
            this.panel29.Margin = new System.Windows.Forms.Padding(0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(64, 59);
            this.panel29.TabIndex = 60;
            // 
            // dButton
            // 
            this.dButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.dButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.dButton.FlatAppearance.BorderSize = 0;
            this.dButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.dButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.dButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dButton.ForeColor = System.Drawing.Color.DarkGray;
            this.dButton.Location = new System.Drawing.Point(0, 0);
            this.dButton.Margin = new System.Windows.Forms.Padding(0);
            this.dButton.Name = "dButton";
            this.dButton.Size = new System.Drawing.Size(64, 59);
            this.dButton.TabIndex = 0;
            this.dButton.TabStop = false;
            this.dButton.Tag = "";
            this.dButton.Text = "D";
            this.dButton.UseVisualStyleBackColor = true;
            this.dButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.dButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.Black;
            this.panel28.Controls.Add(this.sButton);
            this.panel28.Location = new System.Drawing.Point(192, 118);
            this.panel28.Margin = new System.Windows.Forms.Padding(0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(64, 59);
            this.panel28.TabIndex = 59;
            // 
            // sButton
            // 
            this.sButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.sButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.sButton.FlatAppearance.BorderSize = 0;
            this.sButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.sButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.sButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sButton.ForeColor = System.Drawing.Color.DarkGray;
            this.sButton.Location = new System.Drawing.Point(0, 0);
            this.sButton.Margin = new System.Windows.Forms.Padding(0);
            this.sButton.Name = "sButton";
            this.sButton.Size = new System.Drawing.Size(64, 59);
            this.sButton.TabIndex = 0;
            this.sButton.TabStop = false;
            this.sButton.Tag = "";
            this.sButton.Text = "S";
            this.sButton.UseVisualStyleBackColor = true;
            this.sButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.sButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Black;
            this.panel14.Controls.Add(this.aButton);
            this.panel14.Location = new System.Drawing.Point(128, 118);
            this.panel14.Margin = new System.Windows.Forms.Padding(0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(64, 59);
            this.panel14.TabIndex = 58;
            // 
            // aButton
            // 
            this.aButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.aButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.aButton.FlatAppearance.BorderSize = 0;
            this.aButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.aButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.aButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aButton.ForeColor = System.Drawing.Color.DarkGray;
            this.aButton.Location = new System.Drawing.Point(0, 0);
            this.aButton.Margin = new System.Windows.Forms.Padding(0);
            this.aButton.Name = "aButton";
            this.aButton.Size = new System.Drawing.Size(64, 59);
            this.aButton.TabIndex = 0;
            this.aButton.TabStop = false;
            this.aButton.Tag = "";
            this.aButton.Text = "A";
            this.aButton.UseVisualStyleBackColor = true;
            this.aButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.aButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.Black;
            this.panel27.Controls.Add(this.backslashButton);
            this.panel27.Location = new System.Drawing.Point(864, 59);
            this.panel27.Margin = new System.Windows.Forms.Padding(0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(64, 59);
            this.panel27.TabIndex = 57;
            // 
            // backslashButton
            // 
            this.backslashButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.backslashButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.backslashButton.FlatAppearance.BorderSize = 0;
            this.backslashButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.backslashButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.backslashButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backslashButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backslashButton.ForeColor = System.Drawing.Color.DarkGray;
            this.backslashButton.Location = new System.Drawing.Point(0, 0);
            this.backslashButton.Margin = new System.Windows.Forms.Padding(0);
            this.backslashButton.Name = "backslashButton";
            this.backslashButton.Size = new System.Drawing.Size(64, 59);
            this.backslashButton.TabIndex = 0;
            this.backslashButton.TabStop = false;
            this.backslashButton.Tag = "";
            this.backslashButton.Text = "|\r\n\\";
            this.backslashButton.UseVisualStyleBackColor = true;
            this.backslashButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.backslashButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.Black;
            this.panel26.Controls.Add(this.rightBracketButton);
            this.panel26.Location = new System.Drawing.Point(800, 59);
            this.panel26.Margin = new System.Windows.Forms.Padding(0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(64, 59);
            this.panel26.TabIndex = 56;
            // 
            // rightBracketButton
            // 
            this.rightBracketButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.rightBracketButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.rightBracketButton.FlatAppearance.BorderSize = 0;
            this.rightBracketButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.rightBracketButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.rightBracketButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rightBracketButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rightBracketButton.ForeColor = System.Drawing.Color.DarkGray;
            this.rightBracketButton.Location = new System.Drawing.Point(0, 0);
            this.rightBracketButton.Margin = new System.Windows.Forms.Padding(0);
            this.rightBracketButton.Name = "rightBracketButton";
            this.rightBracketButton.Size = new System.Drawing.Size(64, 59);
            this.rightBracketButton.TabIndex = 0;
            this.rightBracketButton.TabStop = false;
            this.rightBracketButton.Tag = "";
            this.rightBracketButton.Text = "}\r\n]";
            this.rightBracketButton.UseVisualStyleBackColor = true;
            this.rightBracketButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.rightBracketButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.Black;
            this.panel25.Controls.Add(this.leftBracketButton);
            this.panel25.Location = new System.Drawing.Point(736, 59);
            this.panel25.Margin = new System.Windows.Forms.Padding(0);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(64, 59);
            this.panel25.TabIndex = 55;
            // 
            // leftBracketButton
            // 
            this.leftBracketButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.leftBracketButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.leftBracketButton.FlatAppearance.BorderSize = 0;
            this.leftBracketButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.leftBracketButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.leftBracketButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.leftBracketButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leftBracketButton.ForeColor = System.Drawing.Color.DarkGray;
            this.leftBracketButton.Location = new System.Drawing.Point(0, 0);
            this.leftBracketButton.Margin = new System.Windows.Forms.Padding(0);
            this.leftBracketButton.Name = "leftBracketButton";
            this.leftBracketButton.Size = new System.Drawing.Size(64, 59);
            this.leftBracketButton.TabIndex = 0;
            this.leftBracketButton.TabStop = false;
            this.leftBracketButton.Tag = "";
            this.leftBracketButton.Text = "{\r\n[";
            this.leftBracketButton.UseVisualStyleBackColor = true;
            this.leftBracketButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.leftBracketButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.Black;
            this.panel24.Controls.Add(this.pButton);
            this.panel24.Location = new System.Drawing.Point(672, 59);
            this.panel24.Margin = new System.Windows.Forms.Padding(0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(64, 59);
            this.panel24.TabIndex = 54;
            // 
            // pButton
            // 
            this.pButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.pButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.pButton.FlatAppearance.BorderSize = 0;
            this.pButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.pButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.pButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pButton.ForeColor = System.Drawing.Color.DarkGray;
            this.pButton.Location = new System.Drawing.Point(0, 0);
            this.pButton.Margin = new System.Windows.Forms.Padding(0);
            this.pButton.Name = "pButton";
            this.pButton.Size = new System.Drawing.Size(64, 59);
            this.pButton.TabIndex = 0;
            this.pButton.TabStop = false;
            this.pButton.Tag = "";
            this.pButton.Text = "P";
            this.pButton.UseVisualStyleBackColor = true;
            this.pButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.pButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.Black;
            this.panel23.Controls.Add(this.oButton);
            this.panel23.Location = new System.Drawing.Point(608, 59);
            this.panel23.Margin = new System.Windows.Forms.Padding(0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(64, 59);
            this.panel23.TabIndex = 53;
            // 
            // oButton
            // 
            this.oButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.oButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.oButton.FlatAppearance.BorderSize = 0;
            this.oButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.oButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.oButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.oButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oButton.ForeColor = System.Drawing.Color.DarkGray;
            this.oButton.Location = new System.Drawing.Point(0, 0);
            this.oButton.Margin = new System.Windows.Forms.Padding(0);
            this.oButton.Name = "oButton";
            this.oButton.Size = new System.Drawing.Size(64, 59);
            this.oButton.TabIndex = 0;
            this.oButton.TabStop = false;
            this.oButton.Tag = "";
            this.oButton.Text = "O";
            this.oButton.UseVisualStyleBackColor = true;
            this.oButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.oButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.Black;
            this.panel22.Controls.Add(this.iButton);
            this.panel22.Location = new System.Drawing.Point(544, 59);
            this.panel22.Margin = new System.Windows.Forms.Padding(0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(64, 59);
            this.panel22.TabIndex = 52;
            // 
            // iButton
            // 
            this.iButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.iButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.iButton.FlatAppearance.BorderSize = 0;
            this.iButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.iButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.iButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iButton.ForeColor = System.Drawing.Color.DarkGray;
            this.iButton.Location = new System.Drawing.Point(0, 0);
            this.iButton.Margin = new System.Windows.Forms.Padding(0);
            this.iButton.Name = "iButton";
            this.iButton.Size = new System.Drawing.Size(64, 59);
            this.iButton.TabIndex = 0;
            this.iButton.TabStop = false;
            this.iButton.Tag = "";
            this.iButton.Text = "I";
            this.iButton.UseVisualStyleBackColor = true;
            this.iButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.iButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.Black;
            this.panel21.Controls.Add(this.uButton);
            this.panel21.Location = new System.Drawing.Point(480, 59);
            this.panel21.Margin = new System.Windows.Forms.Padding(0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(64, 59);
            this.panel21.TabIndex = 51;
            // 
            // uButton
            // 
            this.uButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.uButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.uButton.FlatAppearance.BorderSize = 0;
            this.uButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.uButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.uButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.uButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uButton.ForeColor = System.Drawing.Color.DarkGray;
            this.uButton.Location = new System.Drawing.Point(0, 0);
            this.uButton.Margin = new System.Windows.Forms.Padding(0);
            this.uButton.Name = "uButton";
            this.uButton.Size = new System.Drawing.Size(64, 59);
            this.uButton.TabIndex = 0;
            this.uButton.TabStop = false;
            this.uButton.Tag = "";
            this.uButton.Text = "U";
            this.uButton.UseVisualStyleBackColor = true;
            this.uButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.uButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Black;
            this.panel20.Controls.Add(this.yButton);
            this.panel20.Location = new System.Drawing.Point(416, 59);
            this.panel20.Margin = new System.Windows.Forms.Padding(0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(64, 59);
            this.panel20.TabIndex = 50;
            // 
            // yButton
            // 
            this.yButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.yButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.yButton.FlatAppearance.BorderSize = 0;
            this.yButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.yButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.yButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.yButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yButton.ForeColor = System.Drawing.Color.DarkGray;
            this.yButton.Location = new System.Drawing.Point(0, 0);
            this.yButton.Margin = new System.Windows.Forms.Padding(0);
            this.yButton.Name = "yButton";
            this.yButton.Size = new System.Drawing.Size(64, 59);
            this.yButton.TabIndex = 0;
            this.yButton.TabStop = false;
            this.yButton.Tag = "";
            this.yButton.Text = "Y";
            this.yButton.UseVisualStyleBackColor = true;
            this.yButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.yButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.Black;
            this.panel19.Controls.Add(this.tButton);
            this.panel19.Location = new System.Drawing.Point(352, 59);
            this.panel19.Margin = new System.Windows.Forms.Padding(0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(64, 59);
            this.panel19.TabIndex = 49;
            // 
            // tButton
            // 
            this.tButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.tButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.tButton.FlatAppearance.BorderSize = 0;
            this.tButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.tButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.tButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tButton.ForeColor = System.Drawing.Color.DarkGray;
            this.tButton.Location = new System.Drawing.Point(0, 0);
            this.tButton.Margin = new System.Windows.Forms.Padding(0);
            this.tButton.Name = "tButton";
            this.tButton.Size = new System.Drawing.Size(64, 59);
            this.tButton.TabIndex = 0;
            this.tButton.TabStop = false;
            this.tButton.Tag = "";
            this.tButton.Text = "T";
            this.tButton.UseVisualStyleBackColor = true;
            this.tButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.tButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Black;
            this.panel18.Controls.Add(this.rButton);
            this.panel18.Location = new System.Drawing.Point(288, 59);
            this.panel18.Margin = new System.Windows.Forms.Padding(0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(64, 59);
            this.panel18.TabIndex = 48;
            // 
            // rButton
            // 
            this.rButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.rButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.rButton.FlatAppearance.BorderSize = 0;
            this.rButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.rButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.rButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rButton.ForeColor = System.Drawing.Color.DarkGray;
            this.rButton.Location = new System.Drawing.Point(0, 0);
            this.rButton.Margin = new System.Windows.Forms.Padding(0);
            this.rButton.Name = "rButton";
            this.rButton.Size = new System.Drawing.Size(64, 59);
            this.rButton.TabIndex = 0;
            this.rButton.TabStop = false;
            this.rButton.Tag = "";
            this.rButton.Text = "R";
            this.rButton.UseVisualStyleBackColor = true;
            this.rButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.rButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Black;
            this.panel17.Controls.Add(this.eButton);
            this.panel17.Location = new System.Drawing.Point(224, 59);
            this.panel17.Margin = new System.Windows.Forms.Padding(0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(64, 59);
            this.panel17.TabIndex = 47;
            // 
            // eButton
            // 
            this.eButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.eButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.eButton.FlatAppearance.BorderSize = 0;
            this.eButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.eButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.eButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eButton.ForeColor = System.Drawing.Color.DarkGray;
            this.eButton.Location = new System.Drawing.Point(0, 0);
            this.eButton.Margin = new System.Windows.Forms.Padding(0);
            this.eButton.Name = "eButton";
            this.eButton.Size = new System.Drawing.Size(64, 59);
            this.eButton.TabIndex = 0;
            this.eButton.TabStop = false;
            this.eButton.Tag = "";
            this.eButton.Text = "E";
            this.eButton.UseVisualStyleBackColor = true;
            this.eButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.eButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Black;
            this.panel16.Controls.Add(this.wButton);
            this.panel16.Location = new System.Drawing.Point(160, 59);
            this.panel16.Margin = new System.Windows.Forms.Padding(0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(64, 59);
            this.panel16.TabIndex = 46;
            // 
            // wButton
            // 
            this.wButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.wButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.wButton.FlatAppearance.BorderSize = 0;
            this.wButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.wButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.wButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.wButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wButton.ForeColor = System.Drawing.Color.DarkGray;
            this.wButton.Location = new System.Drawing.Point(0, 0);
            this.wButton.Margin = new System.Windows.Forms.Padding(0);
            this.wButton.Name = "wButton";
            this.wButton.Size = new System.Drawing.Size(64, 59);
            this.wButton.TabIndex = 0;
            this.wButton.TabStop = false;
            this.wButton.Tag = "";
            this.wButton.Text = "W";
            this.wButton.UseVisualStyleBackColor = true;
            this.wButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.wButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Black;
            this.panel15.Controls.Add(this.qButton);
            this.panel15.Location = new System.Drawing.Point(96, 59);
            this.panel15.Margin = new System.Windows.Forms.Padding(0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(64, 59);
            this.panel15.TabIndex = 45;
            // 
            // qButton
            // 
            this.qButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.qButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.qButton.FlatAppearance.BorderSize = 0;
            this.qButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.qButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.qButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qButton.ForeColor = System.Drawing.Color.DarkGray;
            this.qButton.Location = new System.Drawing.Point(0, 0);
            this.qButton.Margin = new System.Windows.Forms.Padding(0);
            this.qButton.Name = "qButton";
            this.qButton.Size = new System.Drawing.Size(64, 59);
            this.qButton.TabIndex = 0;
            this.qButton.TabStop = false;
            this.qButton.Tag = "";
            this.qButton.Text = "Q";
            this.qButton.UseVisualStyleBackColor = true;
            this.qButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.qButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Black;
            this.panel13.Controls.Add(this.equalsButton);
            this.panel13.Location = new System.Drawing.Point(768, 0);
            this.panel13.Margin = new System.Windows.Forms.Padding(0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(64, 59);
            this.panel13.TabIndex = 43;
            // 
            // equalsButton
            // 
            this.equalsButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.equalsButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.equalsButton.FlatAppearance.BorderSize = 0;
            this.equalsButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.equalsButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.equalsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.equalsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equalsButton.ForeColor = System.Drawing.Color.DarkGray;
            this.equalsButton.Location = new System.Drawing.Point(0, 0);
            this.equalsButton.Margin = new System.Windows.Forms.Padding(0);
            this.equalsButton.Name = "equalsButton";
            this.equalsButton.Size = new System.Drawing.Size(64, 59);
            this.equalsButton.TabIndex = 0;
            this.equalsButton.TabStop = false;
            this.equalsButton.Tag = "";
            this.equalsButton.Text = "+\r\n=";
            this.equalsButton.UseVisualStyleBackColor = true;
            this.equalsButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.equalsButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Controls.Add(this.eightButton);
            this.panel9.Location = new System.Drawing.Point(512, 0);
            this.panel9.Margin = new System.Windows.Forms.Padding(0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(64, 59);
            this.panel9.TabIndex = 42;
            // 
            // eightButton
            // 
            this.eightButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.eightButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.eightButton.FlatAppearance.BorderSize = 0;
            this.eightButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.eightButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.eightButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eightButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eightButton.ForeColor = System.Drawing.Color.DarkGray;
            this.eightButton.Location = new System.Drawing.Point(0, 0);
            this.eightButton.Margin = new System.Windows.Forms.Padding(0);
            this.eightButton.Name = "eightButton";
            this.eightButton.Size = new System.Drawing.Size(64, 59);
            this.eightButton.TabIndex = 0;
            this.eightButton.TabStop = false;
            this.eightButton.Tag = "";
            this.eightButton.Text = "*\r\n8";
            this.eightButton.UseVisualStyleBackColor = true;
            this.eightButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.eightButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Controls.Add(this.fiveButton);
            this.panel6.Location = new System.Drawing.Point(320, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(64, 59);
            this.panel6.TabIndex = 41;
            // 
            // fiveButton
            // 
            this.fiveButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.fiveButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.fiveButton.FlatAppearance.BorderSize = 0;
            this.fiveButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.fiveButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.fiveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fiveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fiveButton.ForeColor = System.Drawing.Color.DarkGray;
            this.fiveButton.Location = new System.Drawing.Point(0, 0);
            this.fiveButton.Margin = new System.Windows.Forms.Padding(0);
            this.fiveButton.Name = "fiveButton";
            this.fiveButton.Size = new System.Drawing.Size(64, 59);
            this.fiveButton.TabIndex = 0;
            this.fiveButton.TabStop = false;
            this.fiveButton.Tag = "";
            this.fiveButton.Text = "%\r\n5";
            this.fiveButton.UseVisualStyleBackColor = true;
            this.fiveButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.fiveButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.threeButton);
            this.panel1.Location = new System.Drawing.Point(192, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(64, 59);
            this.panel1.TabIndex = 40;
            // 
            // threeButton
            // 
            this.threeButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.threeButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.threeButton.FlatAppearance.BorderSize = 0;
            this.threeButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.threeButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.threeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.threeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threeButton.ForeColor = System.Drawing.Color.DarkGray;
            this.threeButton.Location = new System.Drawing.Point(0, 0);
            this.threeButton.Margin = new System.Windows.Forms.Padding(0);
            this.threeButton.Name = "threeButton";
            this.threeButton.Size = new System.Drawing.Size(64, 59);
            this.threeButton.TabIndex = 0;
            this.threeButton.TabStop = false;
            this.threeButton.Tag = "";
            this.threeButton.Text = "#\r\n3";
            this.threeButton.UseVisualStyleBackColor = true;
            this.threeButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.threeButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Controls.Add(this.twoButton);
            this.panel4.Location = new System.Drawing.Point(128, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(64, 59);
            this.panel4.TabIndex = 39;
            // 
            // twoButton
            // 
            this.twoButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.twoButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.twoButton.FlatAppearance.BorderSize = 0;
            this.twoButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.twoButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.twoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.twoButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoButton.ForeColor = System.Drawing.Color.DarkGray;
            this.twoButton.Location = new System.Drawing.Point(0, 0);
            this.twoButton.Margin = new System.Windows.Forms.Padding(0);
            this.twoButton.Name = "twoButton";
            this.twoButton.Size = new System.Drawing.Size(64, 59);
            this.twoButton.TabIndex = 0;
            this.twoButton.TabStop = false;
            this.twoButton.Tag = "";
            this.twoButton.Text = "@\r\n2";
            this.twoButton.UseVisualStyleBackColor = true;
            this.twoButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.twoButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.graveButton);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(64, 59);
            this.panel2.TabIndex = 38;
            // 
            // graveButton
            // 
            this.graveButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.graveButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.graveButton.FlatAppearance.BorderSize = 0;
            this.graveButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.graveButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.graveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.graveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.graveButton.ForeColor = System.Drawing.Color.DarkGray;
            this.graveButton.Location = new System.Drawing.Point(0, 0);
            this.graveButton.Margin = new System.Windows.Forms.Padding(0);
            this.graveButton.Name = "graveButton";
            this.graveButton.Size = new System.Drawing.Size(64, 59);
            this.graveButton.TabIndex = 0;
            this.graveButton.TabStop = false;
            this.graveButton.Tag = "";
            this.graveButton.Text = "~\r\n`";
            this.graveButton.UseVisualStyleBackColor = true;
            this.graveButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.graveButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.AutoSize = true;
            this.tableLayoutPanel.ColumnCount = 1;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel.Controls.Add(this.keypadOuterPanel, 0, 0);
            this.tableLayoutPanel.Controls.Add(this.helpPictureBox, 0, 1);
            this.tableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 2;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel.Size = new System.Drawing.Size(928, 262);
            this.tableLayoutPanel.TabIndex = 38;
            // 
            // helpPictureBox
            // 
            this.helpPictureBox.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.helpPictureBox.ContextMenuStrip = this.helpContextMenuStrip;
            this.helpPictureBox.Image = global::Wx3270.Properties.Resources.Question23c;
            this.helpPictureBox.Location = new System.Drawing.Point(905, 239);
            this.helpPictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.helpPictureBox.Name = "helpPictureBox";
            this.helpPictureBox.Size = new System.Drawing.Size(20, 20);
            this.helpPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.helpPictureBox.TabIndex = 38;
            this.helpPictureBox.TabStop = false;
            this.toolTip1.SetToolTip(this.helpPictureBox, "Get help");
            this.helpPictureBox.Click += new System.EventHandler(this.HelpClick);
            // 
            // helpContextMenuStrip
            // 
            this.helpContextMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.helpContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.displayHelpInBrowserToolStripMenuItem,
            this.startTourToolStripMenuItem});
            this.helpContextMenuStrip.Name = "helpContextMenuStrip";
            this.helpContextMenuStrip.Size = new System.Drawing.Size(234, 52);
            // 
            // displayHelpInBrowserToolStripMenuItem
            // 
            this.displayHelpInBrowserToolStripMenuItem.Name = "displayHelpInBrowserToolStripMenuItem";
            this.displayHelpInBrowserToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.displayHelpInBrowserToolStripMenuItem.Tag = "Help";
            this.displayHelpInBrowserToolStripMenuItem.Text = "Display help in browser";
            this.displayHelpInBrowserToolStripMenuItem.Click += new System.EventHandler(this.HelpMenuClick);
            // 
            // startTourToolStripMenuItem
            // 
            this.startTourToolStripMenuItem.Name = "startTourToolStripMenuItem";
            this.startTourToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.startTourToolStripMenuItem.Tag = "Tour";
            this.startTourToolStripMenuItem.Text = "Start tour";
            this.startTourToolStripMenuItem.Click += new System.EventHandler(this.HelpMenuClick);
            // 
            // AplKeypad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1812, 489);
            this.Controls.Add(this.tableLayoutPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AplKeypad";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "wx3270 APL Keypad";
            this.Activated += new System.EventHandler(this.Keypad_Activated);
            this.Deactivate += new System.EventHandler(this.Keypad_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Keypad_FormClosing);
            this.Load += new System.EventHandler(this.KeypadLoad);
            this.Enter += new System.EventHandler(this.Keypad_Enter);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Keypad_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keypad_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Keypad_KeyUp);
            this.MouseCaptureChanged += new System.EventHandler(this.Keypad_Enter);
            this.keypadOuterPanel.ResumeLayout(false);
            this.keypadOuterPanel.PerformLayout();
            this.keyboardPanel.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel46.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel40.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel.ResumeLayout(false);
            this.tableLayoutPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.helpPictureBox)).EndInit();
            this.helpContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel keypadOuterPanel;
        public System.Windows.Forms.Panel keyboardPanel;
        private System.Windows.Forms.Panel panel12;
        private NoSelectButton minusButton;
        private System.Windows.Forms.Panel panel47;
        private NoSelectButton slashButton;
        private System.Windows.Forms.Panel panel46;
        private NoSelectButton periodButton;
        private System.Windows.Forms.Panel panel45;
        private NoSelectButton commaButton;
        private System.Windows.Forms.Panel panel11;
        private NoSelectButton zeroButton;
        private System.Windows.Forms.Panel panel5;
        private NoSelectButton fourButton;
        private System.Windows.Forms.Panel panel10;
        private NoSelectButton nineButton;
        private System.Windows.Forms.Panel panel8;
        private NoSelectButton sevenButton;
        private System.Windows.Forms.Panel panel3;
        private NoSelectButton oneButton;
        private System.Windows.Forms.Panel panel44;
        private NoSelectButton mButton;
        private System.Windows.Forms.Panel panel7;
        private NoSelectButton sixButton;
        private System.Windows.Forms.Panel panel43;
        private NoSelectButton nButton;
        private System.Windows.Forms.Panel panel42;
        private NoSelectButton bButton;
        private System.Windows.Forms.Panel panel41;
        private NoSelectButton vButton;
        private System.Windows.Forms.Panel panel40;
        private NoSelectButton cButton;
        private System.Windows.Forms.Panel panel39;
        private NoSelectButton xButton;
        private System.Windows.Forms.Panel panel38;
        private NoSelectButton zButton;
        private System.Windows.Forms.Panel panel37;
        private NoSelectButton apostropheButton;
        private System.Windows.Forms.Panel panel36;
        private NoSelectButton semicolonButton;
        private System.Windows.Forms.Panel panel35;
        private NoSelectButton lButton;
        private System.Windows.Forms.Panel panel34;
        private NoSelectButton kButton;
        private System.Windows.Forms.Panel panel33;
        private NoSelectButton jButton;
        private System.Windows.Forms.Panel panel32;
        private NoSelectButton hButton;
        private System.Windows.Forms.Panel panel31;
        private NoSelectButton gButton;
        private System.Windows.Forms.Panel panel30;
        private NoSelectButton fButton;
        private System.Windows.Forms.Panel panel29;
        private NoSelectButton dButton;
        private System.Windows.Forms.Panel panel28;
        private NoSelectButton sButton;
        private System.Windows.Forms.Panel panel14;
        private NoSelectButton aButton;
        private System.Windows.Forms.Panel panel27;
        private NoSelectButton backslashButton;
        private System.Windows.Forms.Panel panel26;
        private NoSelectButton rightBracketButton;
        private System.Windows.Forms.Panel panel25;
        private NoSelectButton leftBracketButton;
        private System.Windows.Forms.Panel panel24;
        private NoSelectButton pButton;
        private System.Windows.Forms.Panel panel23;
        private NoSelectButton oButton;
        private System.Windows.Forms.Panel panel22;
        private NoSelectButton iButton;
        private System.Windows.Forms.Panel panel21;
        private NoSelectButton uButton;
        private System.Windows.Forms.Panel panel20;
        private NoSelectButton yButton;
        private System.Windows.Forms.Panel panel19;
        private NoSelectButton tButton;
        private System.Windows.Forms.Panel panel18;
        private NoSelectButton rButton;
        private System.Windows.Forms.Panel panel17;
        private NoSelectButton eButton;
        private System.Windows.Forms.Panel panel16;
        private NoSelectButton wButton;
        private System.Windows.Forms.Panel panel15;
        private NoSelectButton qButton;
        private System.Windows.Forms.Panel panel13;
        private NoSelectButton equalsButton;
        private System.Windows.Forms.Panel panel9;
        private NoSelectButton eightButton;
        private System.Windows.Forms.Panel panel6;
        private NoSelectButton fiveButton;
        private System.Windows.Forms.Panel panel1;
        private NoSelectButton threeButton;
        private System.Windows.Forms.Panel panel4;
        private NoSelectButton twoButton;
        private System.Windows.Forms.Panel panel2;
        private NoSelectButton graveButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.PictureBox helpPictureBox;
        private System.Windows.Forms.ContextMenuStrip helpContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem displayHelpInBrowserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startTourToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}