﻿namespace Wx3270
{
    partial class KeyboardPicture
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KeyboardPicture));
            this.escapeKey = new System.Windows.Forms.Label();
            this.f1Key = new System.Windows.Forms.Label();
            this.f2Key = new System.Windows.Forms.Label();
            this.f3Key = new System.Windows.Forms.Label();
            this.f7Key = new System.Windows.Forms.Label();
            this.f6Key = new System.Windows.Forms.Label();
            this.f5Key = new System.Windows.Forms.Label();
            this.f4Key = new System.Windows.Forms.Label();
            this.f9Key = new System.Windows.Forms.Label();
            this.f8Key = new System.Windows.Forms.Label();
            this.f11Key = new System.Windows.Forms.Label();
            this.f10Key = new System.Windows.Forms.Label();
            this.f12Key = new System.Windows.Forms.Label();
            this.prtScnKey = new System.Windows.Forms.Label();
            this.scrollLockKey = new System.Windows.Forms.Label();
            this.pauseKey = new System.Windows.Forms.Label();
            this.pageUpKey = new System.Windows.Forms.Label();
            this.homeKey = new System.Windows.Forms.Label();
            this.insertKey = new System.Windows.Forms.Label();
            this.pageDownKey = new System.Windows.Forms.Label();
            this.endKey = new System.Windows.Forms.Label();
            this.deleteKey = new System.Windows.Forms.Label();
            this.upKey = new System.Windows.Forms.Label();
            this.rightKey = new System.Windows.Forms.Label();
            this.downKey = new System.Windows.Forms.Label();
            this.leftKey = new System.Windows.Forms.Label();
            this.subtractKey = new System.Windows.Forms.Label();
            this.multiplyKey = new System.Windows.Forms.Label();
            this.divideKey = new System.Windows.Forms.Label();
            this.numLockKey = new System.Windows.Forms.Label();
            this.num9Key = new System.Windows.Forms.Label();
            this.num8Key = new System.Windows.Forms.Label();
            this.num7Key = new System.Windows.Forms.Label();
            this.num6key = new System.Windows.Forms.Label();
            this.num5key = new System.Windows.Forms.Label();
            this.num4key = new System.Windows.Forms.Label();
            this.num3Key = new System.Windows.Forms.Label();
            this.num2Key = new System.Windows.Forms.Label();
            this.num1Key = new System.Windows.Forms.Label();
            this.decimalKey = new System.Windows.Forms.Label();
            this.num0Key = new System.Windows.Forms.Label();
            this.addKey = new System.Windows.Forms.Label();
            this.numEnterKey = new System.Windows.Forms.Label();
            this.key29 = new System.Windows.Forms.Label();
            this.key2 = new System.Windows.Forms.Label();
            this.key3 = new System.Windows.Forms.Label();
            this.key4 = new System.Windows.Forms.Label();
            this.key5 = new System.Windows.Forms.Label();
            this.key6 = new System.Windows.Forms.Label();
            this.key7 = new System.Windows.Forms.Label();
            this.key8 = new System.Windows.Forms.Label();
            this.key9 = new System.Windows.Forms.Label();
            this.keyA = new System.Windows.Forms.Label();
            this.keyC = new System.Windows.Forms.Label();
            this.keyD = new System.Windows.Forms.Label();
            this.backSpaceKey = new System.Windows.Forms.Label();
            this.tabKey = new System.Windows.Forms.Label();
            this.key10 = new System.Windows.Forms.Label();
            this.key11 = new System.Windows.Forms.Label();
            this.key12 = new System.Windows.Forms.Label();
            this.key13 = new System.Windows.Forms.Label();
            this.key14 = new System.Windows.Forms.Label();
            this.key15 = new System.Windows.Forms.Label();
            this.key16 = new System.Windows.Forms.Label();
            this.key17 = new System.Windows.Forms.Label();
            this.key18 = new System.Windows.Forms.Label();
            this.key19 = new System.Windows.Forms.Label();
            this.key1A = new System.Windows.Forms.Label();
            this.key1B = new System.Windows.Forms.Label();
            this.key2B = new System.Windows.Forms.Label();
            this.keyB = new System.Windows.Forms.Label();
            this.key28 = new System.Windows.Forms.Label();
            this.key27 = new System.Windows.Forms.Label();
            this.key26 = new System.Windows.Forms.Label();
            this.key25 = new System.Windows.Forms.Label();
            this.key24 = new System.Windows.Forms.Label();
            this.key23 = new System.Windows.Forms.Label();
            this.key22 = new System.Windows.Forms.Label();
            this.key21 = new System.Windows.Forms.Label();
            this.key20 = new System.Windows.Forms.Label();
            this.key1F = new System.Windows.Forms.Label();
            this.key1E = new System.Windows.Forms.Label();
            this.capsLockKey = new System.Windows.Forms.Label();
            this.enterKey = new System.Windows.Forms.Label();
            this.key35 = new System.Windows.Forms.Label();
            this.key34 = new System.Windows.Forms.Label();
            this.key33 = new System.Windows.Forms.Label();
            this.key32 = new System.Windows.Forms.Label();
            this.key31 = new System.Windows.Forms.Label();
            this.key30 = new System.Windows.Forms.Label();
            this.key2F = new System.Windows.Forms.Label();
            this.key2E = new System.Windows.Forms.Label();
            this.key2D = new System.Windows.Forms.Label();
            this.key2C = new System.Windows.Forms.Label();
            this.leftShiftKey = new System.Windows.Forms.Label();
            this.rightShiftKey = new System.Windows.Forms.Label();
            this.leftWinKey = new System.Windows.Forms.Label();
            this.leftAltKey = new System.Windows.Forms.Label();
            this.rightAltKey = new System.Windows.Forms.Label();
            this.appsKey = new System.Windows.Forms.Label();
            this.rightCtrlKey = new System.Windows.Forms.Label();
            this.leftCtrlKey = new System.Windows.Forms.Label();
            this.spaceBar = new System.Windows.Forms.Label();
            this.labelsRadioButton = new System.Windows.Forms.RadioButton();
            this.keyNamesRadioButton = new System.Windows.Forms.RadioButton();
            this.definitionsRadioButton = new System.Windows.Forms.RadioButton();
            this.numLockCheckBox = new System.Windows.Forms.CheckBox();
            this.shiftCheckBox = new System.Windows.Forms.CheckBox();
            this.ctrlCheckBox = new System.Windows.Forms.CheckBox();
            this.altCheckBox = new System.Windows.Forms.CheckBox();
            this.displayGroupBox = new System.Windows.Forms.GroupBox();
            this.displayLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.displayTable = new System.Windows.Forms.TableLayoutPanel();
            this.scanCodesRadioButton = new System.Windows.Forms.RadioButton();
            this.modifiersGroupBox = new System.Windows.Forms.GroupBox();
            this.modifiersLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.modifiersTable = new System.Windows.Forms.TableLayoutPanel();
            this.scrollLockCheckBox = new System.Windows.Forms.CheckBox();
            this.rightWinKey = new System.Windows.Forms.Label();
            this.noteLabel = new System.Windows.Forms.Label();
            this.modeGroupBox = new System.Windows.Forms.GroupBox();
            this.modeLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.modeTable = new System.Windows.Forms.TableLayoutPanel();
            this.mode3270CheckBox = new System.Windows.Forms.CheckBox();
            this.nvtModeCheckBox = new System.Windows.Forms.CheckBox();
            this.key56 = new System.Windows.Forms.Label();
            this.nativeNameLabel = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.helpPictureBox = new System.Windows.Forms.PictureBox();
            this.helpContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.displayHelpInBrowserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startTourToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aplLegendPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.aplShiftLabel = new System.Windows.Forms.Label();
            this.aplCtrlShiftLabel = new System.Windows.Forms.Label();
            this.aplNormalLabel = new System.Windows.Forms.Label();
            this.aplCtrlLabel = new System.Windows.Forms.Label();
            this.aplLegendLabel = new System.Windows.Forms.Label();
            this.keysPanel = new System.Windows.Forms.Panel();
            this.layoutLabel = new System.Windows.Forms.Label();
            this.modeFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.chordBox = new System.Windows.Forms.GroupBox();
            this.chordComboBox = new System.Windows.Forms.ComboBox();
            this.bottomTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.displayGroupBox.SuspendLayout();
            this.displayTable.SuspendLayout();
            this.modifiersGroupBox.SuspendLayout();
            this.modifiersTable.SuspendLayout();
            this.modeGroupBox.SuspendLayout();
            this.modeTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.helpPictureBox)).BeginInit();
            this.helpContextMenuStrip.SuspendLayout();
            this.aplLegendPanel.SuspendLayout();
            this.keysPanel.SuspendLayout();
            this.modeFlowLayoutPanel.SuspendLayout();
            this.chordBox.SuspendLayout();
            this.bottomTableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // escapeKey
            // 
            this.escapeKey.AutoEllipsis = true;
            this.escapeKey.BackColor = System.Drawing.Color.Gainsboro;
            this.escapeKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.escapeKey.Location = new System.Drawing.Point(9, 10);
            this.escapeKey.Name = "escapeKey";
            this.escapeKey.Size = new System.Drawing.Size(48, 48);
            this.escapeKey.TabIndex = 0;
            this.escapeKey.Tag = "Escape";
            this.escapeKey.Text = "Esc";
            this.escapeKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.escapeKey.UseMnemonic = false;
            this.escapeKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f1Key
            // 
            this.f1Key.AutoEllipsis = true;
            this.f1Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f1Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f1Key.Location = new System.Drawing.Point(92, 10);
            this.f1Key.Name = "f1Key";
            this.f1Key.Size = new System.Drawing.Size(48, 48);
            this.f1Key.TabIndex = 1;
            this.f1Key.Tag = "F1";
            this.f1Key.Text = "F1";
            this.f1Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f1Key.UseMnemonic = false;
            this.f1Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f2Key
            // 
            this.f2Key.AutoEllipsis = true;
            this.f2Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f2Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f2Key.Location = new System.Drawing.Point(146, 10);
            this.f2Key.Name = "f2Key";
            this.f2Key.Size = new System.Drawing.Size(48, 48);
            this.f2Key.TabIndex = 2;
            this.f2Key.Tag = "F2";
            this.f2Key.Text = "F2";
            this.f2Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f2Key.UseMnemonic = false;
            this.f2Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f3Key
            // 
            this.f3Key.AutoEllipsis = true;
            this.f3Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f3Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f3Key.Location = new System.Drawing.Point(200, 10);
            this.f3Key.Name = "f3Key";
            this.f3Key.Size = new System.Drawing.Size(48, 48);
            this.f3Key.TabIndex = 3;
            this.f3Key.Tag = "F3";
            this.f3Key.Text = "F3";
            this.f3Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f3Key.UseMnemonic = false;
            this.f3Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f7Key
            // 
            this.f7Key.AutoEllipsis = true;
            this.f7Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f7Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f7Key.Location = new System.Drawing.Point(448, 10);
            this.f7Key.Name = "f7Key";
            this.f7Key.Size = new System.Drawing.Size(48, 48);
            this.f7Key.TabIndex = 7;
            this.f7Key.Tag = "F7";
            this.f7Key.Text = "F7";
            this.f7Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f7Key.UseMnemonic = false;
            this.f7Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f6Key
            // 
            this.f6Key.AutoEllipsis = true;
            this.f6Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f6Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f6Key.Location = new System.Drawing.Point(394, 10);
            this.f6Key.Name = "f6Key";
            this.f6Key.Size = new System.Drawing.Size(48, 48);
            this.f6Key.TabIndex = 6;
            this.f6Key.Tag = "F6";
            this.f6Key.Text = "F6";
            this.f6Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f6Key.UseMnemonic = false;
            this.f6Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f5Key
            // 
            this.f5Key.AutoEllipsis = true;
            this.f5Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f5Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f5Key.Location = new System.Drawing.Point(340, 10);
            this.f5Key.Name = "f5Key";
            this.f5Key.Size = new System.Drawing.Size(48, 48);
            this.f5Key.TabIndex = 5;
            this.f5Key.Tag = "F5";
            this.f5Key.Text = "F5";
            this.f5Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f5Key.UseMnemonic = false;
            this.f5Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f4Key
            // 
            this.f4Key.AutoEllipsis = true;
            this.f4Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f4Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f4Key.Location = new System.Drawing.Point(254, 10);
            this.f4Key.Name = "f4Key";
            this.f4Key.Size = new System.Drawing.Size(48, 48);
            this.f4Key.TabIndex = 4;
            this.f4Key.Tag = "F4";
            this.f4Key.Text = "F4";
            this.f4Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f4Key.UseMnemonic = false;
            this.f4Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f9Key
            // 
            this.f9Key.AutoEllipsis = true;
            this.f9Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f9Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f9Key.Location = new System.Drawing.Point(587, 10);
            this.f9Key.Name = "f9Key";
            this.f9Key.Size = new System.Drawing.Size(48, 48);
            this.f9Key.TabIndex = 9;
            this.f9Key.Tag = "F9";
            this.f9Key.Text = "F9";
            this.f9Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f9Key.UseMnemonic = false;
            this.f9Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f8Key
            // 
            this.f8Key.AutoEllipsis = true;
            this.f8Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f8Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f8Key.Location = new System.Drawing.Point(502, 10);
            this.f8Key.Name = "f8Key";
            this.f8Key.Size = new System.Drawing.Size(48, 48);
            this.f8Key.TabIndex = 8;
            this.f8Key.Tag = "F8";
            this.f8Key.Text = "F8";
            this.f8Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f8Key.UseMnemonic = false;
            this.f8Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f11Key
            // 
            this.f11Key.AutoEllipsis = true;
            this.f11Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f11Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f11Key.Location = new System.Drawing.Point(695, 10);
            this.f11Key.Name = "f11Key";
            this.f11Key.Size = new System.Drawing.Size(48, 48);
            this.f11Key.TabIndex = 11;
            this.f11Key.Tag = "F11";
            this.f11Key.Text = "F11";
            this.f11Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f11Key.UseMnemonic = false;
            this.f11Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f10Key
            // 
            this.f10Key.AutoEllipsis = true;
            this.f10Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f10Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f10Key.Location = new System.Drawing.Point(641, 10);
            this.f10Key.Name = "f10Key";
            this.f10Key.Size = new System.Drawing.Size(48, 48);
            this.f10Key.TabIndex = 10;
            this.f10Key.Tag = "F10";
            this.f10Key.Text = "F10";
            this.f10Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f10Key.UseMnemonic = false;
            this.f10Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // f12Key
            // 
            this.f12Key.AutoEllipsis = true;
            this.f12Key.BackColor = System.Drawing.Color.Gainsboro;
            this.f12Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f12Key.Location = new System.Drawing.Point(749, 10);
            this.f12Key.Name = "f12Key";
            this.f12Key.Size = new System.Drawing.Size(48, 48);
            this.f12Key.TabIndex = 12;
            this.f12Key.Tag = "F12";
            this.f12Key.Text = "F12";
            this.f12Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.f12Key.UseMnemonic = false;
            this.f12Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // prtScnKey
            // 
            this.prtScnKey.AutoEllipsis = true;
            this.prtScnKey.BackColor = System.Drawing.Color.Gainsboro;
            this.prtScnKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.prtScnKey.Location = new System.Drawing.Point(829, 10);
            this.prtScnKey.Name = "prtScnKey";
            this.prtScnKey.Size = new System.Drawing.Size(48, 48);
            this.prtScnKey.TabIndex = 13;
            this.prtScnKey.Tag = "PrintScreen";
            this.prtScnKey.Text = "PrtScn\r\n\r\nSysRq";
            this.prtScnKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.prtScnKey.UseMnemonic = false;
            this.prtScnKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // scrollLockKey
            // 
            this.scrollLockKey.AutoEllipsis = true;
            this.scrollLockKey.BackColor = System.Drawing.Color.Gainsboro;
            this.scrollLockKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.scrollLockKey.Location = new System.Drawing.Point(883, 10);
            this.scrollLockKey.Name = "scrollLockKey";
            this.scrollLockKey.Size = new System.Drawing.Size(48, 48);
            this.scrollLockKey.TabIndex = 14;
            this.scrollLockKey.Tag = "Scroll";
            this.scrollLockKey.Text = "Scroll\r\nLock";
            this.scrollLockKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.scrollLockKey.UseMnemonic = false;
            this.scrollLockKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // pauseKey
            // 
            this.pauseKey.AutoEllipsis = true;
            this.pauseKey.BackColor = System.Drawing.Color.Gainsboro;
            this.pauseKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pauseKey.Location = new System.Drawing.Point(937, 10);
            this.pauseKey.Name = "pauseKey";
            this.pauseKey.Size = new System.Drawing.Size(48, 48);
            this.pauseKey.TabIndex = 15;
            this.pauseKey.Tag = "Pause";
            this.pauseKey.Text = "Pause\r\n\r\nBreak";
            this.pauseKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pauseKey.UseMnemonic = false;
            this.pauseKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // pageUpKey
            // 
            this.pageUpKey.AutoEllipsis = true;
            this.pageUpKey.BackColor = System.Drawing.Color.Gainsboro;
            this.pageUpKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pageUpKey.Location = new System.Drawing.Point(937, 81);
            this.pageUpKey.Name = "pageUpKey";
            this.pageUpKey.Size = new System.Drawing.Size(48, 48);
            this.pageUpKey.TabIndex = 18;
            this.pageUpKey.Tag = "PageUp";
            this.pageUpKey.Text = "Page\r\nUp";
            this.pageUpKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pageUpKey.UseMnemonic = false;
            this.pageUpKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // homeKey
            // 
            this.homeKey.AutoEllipsis = true;
            this.homeKey.BackColor = System.Drawing.Color.Gainsboro;
            this.homeKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.homeKey.Location = new System.Drawing.Point(883, 81);
            this.homeKey.Name = "homeKey";
            this.homeKey.Size = new System.Drawing.Size(48, 48);
            this.homeKey.TabIndex = 17;
            this.homeKey.Tag = "Home";
            this.homeKey.Text = "Home";
            this.homeKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.homeKey.UseMnemonic = false;
            this.homeKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // insertKey
            // 
            this.insertKey.AutoEllipsis = true;
            this.insertKey.BackColor = System.Drawing.Color.Gainsboro;
            this.insertKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.insertKey.Location = new System.Drawing.Point(829, 81);
            this.insertKey.Name = "insertKey";
            this.insertKey.Size = new System.Drawing.Size(48, 48);
            this.insertKey.TabIndex = 16;
            this.insertKey.Tag = "Insert";
            this.insertKey.Text = "Insert";
            this.insertKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.insertKey.UseMnemonic = false;
            this.insertKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // pageDownKey
            // 
            this.pageDownKey.AutoEllipsis = true;
            this.pageDownKey.BackColor = System.Drawing.Color.Gainsboro;
            this.pageDownKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pageDownKey.Location = new System.Drawing.Point(937, 138);
            this.pageDownKey.Name = "pageDownKey";
            this.pageDownKey.Size = new System.Drawing.Size(48, 48);
            this.pageDownKey.TabIndex = 21;
            this.pageDownKey.Tag = "Next";
            this.pageDownKey.Text = "Page\r\nDown";
            this.pageDownKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pageDownKey.UseMnemonic = false;
            this.pageDownKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // endKey
            // 
            this.endKey.AutoEllipsis = true;
            this.endKey.BackColor = System.Drawing.Color.Gainsboro;
            this.endKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.endKey.Location = new System.Drawing.Point(883, 138);
            this.endKey.Name = "endKey";
            this.endKey.Size = new System.Drawing.Size(48, 48);
            this.endKey.TabIndex = 20;
            this.endKey.Tag = "End";
            this.endKey.Text = "End";
            this.endKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.endKey.UseMnemonic = false;
            this.endKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // deleteKey
            // 
            this.deleteKey.AutoEllipsis = true;
            this.deleteKey.BackColor = System.Drawing.Color.Gainsboro;
            this.deleteKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.deleteKey.Location = new System.Drawing.Point(829, 138);
            this.deleteKey.Name = "deleteKey";
            this.deleteKey.Size = new System.Drawing.Size(48, 48);
            this.deleteKey.TabIndex = 19;
            this.deleteKey.Tag = "Delete";
            this.deleteKey.Text = "Delete";
            this.deleteKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.deleteKey.UseMnemonic = false;
            this.deleteKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // upKey
            // 
            this.upKey.AutoEllipsis = true;
            this.upKey.BackColor = System.Drawing.Color.Gainsboro;
            this.upKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.upKey.Location = new System.Drawing.Point(883, 252);
            this.upKey.Name = "upKey";
            this.upKey.Size = new System.Drawing.Size(48, 48);
            this.upKey.TabIndex = 22;
            this.upKey.Tag = "Up";
            this.upKey.Text = "↑";
            this.upKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.upKey.UseMnemonic = false;
            this.upKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // rightKey
            // 
            this.rightKey.AutoEllipsis = true;
            this.rightKey.BackColor = System.Drawing.Color.Gainsboro;
            this.rightKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rightKey.Location = new System.Drawing.Point(937, 310);
            this.rightKey.Name = "rightKey";
            this.rightKey.Size = new System.Drawing.Size(48, 48);
            this.rightKey.TabIndex = 25;
            this.rightKey.Tag = "Right";
            this.rightKey.Text = "→";
            this.rightKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rightKey.UseMnemonic = false;
            this.rightKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // downKey
            // 
            this.downKey.AutoEllipsis = true;
            this.downKey.BackColor = System.Drawing.Color.Gainsboro;
            this.downKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.downKey.Location = new System.Drawing.Point(883, 310);
            this.downKey.Name = "downKey";
            this.downKey.Size = new System.Drawing.Size(48, 48);
            this.downKey.TabIndex = 24;
            this.downKey.Tag = "Down";
            this.downKey.Text = "↓";
            this.downKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.downKey.UseMnemonic = false;
            this.downKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // leftKey
            // 
            this.leftKey.AutoEllipsis = true;
            this.leftKey.BackColor = System.Drawing.Color.Gainsboro;
            this.leftKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.leftKey.Location = new System.Drawing.Point(829, 310);
            this.leftKey.Name = "leftKey";
            this.leftKey.Size = new System.Drawing.Size(48, 48);
            this.leftKey.TabIndex = 23;
            this.leftKey.Tag = "Left";
            this.leftKey.Text = "←";
            this.leftKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.leftKey.UseMnemonic = false;
            this.leftKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // subtractKey
            // 
            this.subtractKey.AutoEllipsis = true;
            this.subtractKey.BackColor = System.Drawing.Color.Gainsboro;
            this.subtractKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.subtractKey.Location = new System.Drawing.Point(1179, 81);
            this.subtractKey.Name = "subtractKey";
            this.subtractKey.Size = new System.Drawing.Size(48, 48);
            this.subtractKey.TabIndex = 29;
            this.subtractKey.Tag = "Subtract";
            this.subtractKey.Text = "-";
            this.subtractKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.subtractKey.UseMnemonic = false;
            this.subtractKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // multiplyKey
            // 
            this.multiplyKey.AutoEllipsis = true;
            this.multiplyKey.BackColor = System.Drawing.Color.Gainsboro;
            this.multiplyKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.multiplyKey.Location = new System.Drawing.Point(1125, 81);
            this.multiplyKey.Name = "multiplyKey";
            this.multiplyKey.Size = new System.Drawing.Size(48, 48);
            this.multiplyKey.TabIndex = 28;
            this.multiplyKey.Tag = "Multiply";
            this.multiplyKey.Text = "*";
            this.multiplyKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.multiplyKey.UseMnemonic = false;
            this.multiplyKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // divideKey
            // 
            this.divideKey.AutoEllipsis = true;
            this.divideKey.BackColor = System.Drawing.Color.Gainsboro;
            this.divideKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.divideKey.Location = new System.Drawing.Point(1071, 81);
            this.divideKey.Name = "divideKey";
            this.divideKey.Size = new System.Drawing.Size(48, 48);
            this.divideKey.TabIndex = 27;
            this.divideKey.Tag = "Divide";
            this.divideKey.Text = "/";
            this.divideKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.divideKey.UseMnemonic = false;
            this.divideKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // numLockKey
            // 
            this.numLockKey.AutoEllipsis = true;
            this.numLockKey.BackColor = System.Drawing.Color.Gainsboro;
            this.numLockKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numLockKey.Location = new System.Drawing.Point(1017, 81);
            this.numLockKey.Name = "numLockKey";
            this.numLockKey.Size = new System.Drawing.Size(48, 48);
            this.numLockKey.TabIndex = 26;
            this.numLockKey.Tag = "NumLock";
            this.numLockKey.Text = "Num\r\nLock";
            this.numLockKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.numLockKey.UseMnemonic = false;
            this.numLockKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num9Key
            // 
            this.num9Key.AutoEllipsis = true;
            this.num9Key.BackColor = System.Drawing.Color.Gainsboro;
            this.num9Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num9Key.Location = new System.Drawing.Point(1125, 138);
            this.num9Key.Name = "num9Key";
            this.num9Key.Size = new System.Drawing.Size(48, 48);
            this.num9Key.TabIndex = 32;
            this.num9Key.Tag = "NumPad9 PageUp";
            this.num9Key.Text = "9\r\n\r\nPgUp";
            this.num9Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num9Key.UseMnemonic = false;
            this.num9Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num8Key
            // 
            this.num8Key.AutoEllipsis = true;
            this.num8Key.BackColor = System.Drawing.Color.Gainsboro;
            this.num8Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num8Key.Location = new System.Drawing.Point(1071, 138);
            this.num8Key.Name = "num8Key";
            this.num8Key.Size = new System.Drawing.Size(48, 48);
            this.num8Key.TabIndex = 31;
            this.num8Key.Tag = "NumPad8 Up";
            this.num8Key.Text = "8\r\n\r\n↑";
            this.num8Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num8Key.UseMnemonic = false;
            this.num8Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num7Key
            // 
            this.num7Key.AutoEllipsis = true;
            this.num7Key.BackColor = System.Drawing.Color.Gainsboro;
            this.num7Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num7Key.Location = new System.Drawing.Point(1017, 138);
            this.num7Key.Name = "num7Key";
            this.num7Key.Size = new System.Drawing.Size(48, 48);
            this.num7Key.TabIndex = 30;
            this.num7Key.Tag = "NumPad7 Home";
            this.num7Key.Text = "7\r\n\r\nHome";
            this.num7Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num7Key.UseMnemonic = false;
            this.num7Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num6key
            // 
            this.num6key.AutoEllipsis = true;
            this.num6key.BackColor = System.Drawing.Color.Gainsboro;
            this.num6key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num6key.Location = new System.Drawing.Point(1125, 195);
            this.num6key.Name = "num6key";
            this.num6key.Size = new System.Drawing.Size(48, 48);
            this.num6key.TabIndex = 35;
            this.num6key.Tag = "NumPad6 Right";
            this.num6key.Text = "6\r\n\r\n→";
            this.num6key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num6key.UseMnemonic = false;
            this.num6key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num5key
            // 
            this.num5key.AutoEllipsis = true;
            this.num5key.BackColor = System.Drawing.Color.Gainsboro;
            this.num5key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num5key.Location = new System.Drawing.Point(1071, 195);
            this.num5key.Name = "num5key";
            this.num5key.Size = new System.Drawing.Size(48, 48);
            this.num5key.TabIndex = 34;
            this.num5key.Tag = "NumPad5 Clear";
            this.num5key.Text = "5\r\n\r\n";
            this.num5key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num5key.UseMnemonic = false;
            this.num5key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num4key
            // 
            this.num4key.AutoEllipsis = true;
            this.num4key.BackColor = System.Drawing.Color.Gainsboro;
            this.num4key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num4key.Location = new System.Drawing.Point(1017, 195);
            this.num4key.Name = "num4key";
            this.num4key.Size = new System.Drawing.Size(48, 48);
            this.num4key.TabIndex = 33;
            this.num4key.Tag = "NumPad4 Left";
            this.num4key.Text = "4\r\n\r\n←";
            this.num4key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num4key.UseMnemonic = false;
            this.num4key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num3Key
            // 
            this.num3Key.AutoEllipsis = true;
            this.num3Key.BackColor = System.Drawing.Color.Gainsboro;
            this.num3Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num3Key.Location = new System.Drawing.Point(1125, 252);
            this.num3Key.Name = "num3Key";
            this.num3Key.Size = new System.Drawing.Size(48, 48);
            this.num3Key.TabIndex = 38;
            this.num3Key.Tag = "NumPad3 Next";
            this.num3Key.Text = "3\r\n\r\nPgDn";
            this.num3Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num3Key.UseMnemonic = false;
            this.num3Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num2Key
            // 
            this.num2Key.AutoEllipsis = true;
            this.num2Key.BackColor = System.Drawing.Color.Gainsboro;
            this.num2Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num2Key.Location = new System.Drawing.Point(1071, 252);
            this.num2Key.Name = "num2Key";
            this.num2Key.Size = new System.Drawing.Size(48, 48);
            this.num2Key.TabIndex = 37;
            this.num2Key.Tag = "NumPad2 Down";
            this.num2Key.Text = "2\r\n\r\n↓";
            this.num2Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num2Key.UseMnemonic = false;
            this.num2Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num1Key
            // 
            this.num1Key.AutoEllipsis = true;
            this.num1Key.BackColor = System.Drawing.Color.Gainsboro;
            this.num1Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num1Key.Location = new System.Drawing.Point(1017, 252);
            this.num1Key.Name = "num1Key";
            this.num1Key.Size = new System.Drawing.Size(48, 48);
            this.num1Key.TabIndex = 36;
            this.num1Key.Tag = "NumPad1 End";
            this.num1Key.Text = "1\r\n\r\nEnd";
            this.num1Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num1Key.UseMnemonic = false;
            this.num1Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // decimalKey
            // 
            this.decimalKey.AutoEllipsis = true;
            this.decimalKey.BackColor = System.Drawing.Color.Gainsboro;
            this.decimalKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.decimalKey.Location = new System.Drawing.Point(1125, 309);
            this.decimalKey.Name = "decimalKey";
            this.decimalKey.Size = new System.Drawing.Size(48, 48);
            this.decimalKey.TabIndex = 39;
            this.decimalKey.Tag = "Decimal Delete";
            this.decimalKey.Text = ".\r\n\r\nDel";
            this.decimalKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.decimalKey.UseMnemonic = false;
            this.decimalKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // num0Key
            // 
            this.num0Key.AutoEllipsis = true;
            this.num0Key.BackColor = System.Drawing.Color.Gainsboro;
            this.num0Key.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.num0Key.Location = new System.Drawing.Point(1017, 309);
            this.num0Key.Name = "num0Key";
            this.num0Key.Size = new System.Drawing.Size(102, 48);
            this.num0Key.TabIndex = 40;
            this.num0Key.Tag = "NumPad0 Insert";
            this.num0Key.Text = "0\r\n\r\nIns";
            this.num0Key.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.num0Key.UseMnemonic = false;
            this.num0Key.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // addKey
            // 
            this.addKey.AutoEllipsis = true;
            this.addKey.BackColor = System.Drawing.Color.Gainsboro;
            this.addKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addKey.Location = new System.Drawing.Point(1179, 138);
            this.addKey.Name = "addKey";
            this.addKey.Size = new System.Drawing.Size(48, 105);
            this.addKey.TabIndex = 41;
            this.addKey.Tag = "Add";
            this.addKey.Text = "+";
            this.addKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.addKey.UseMnemonic = false;
            this.addKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // numEnterKey
            // 
            this.numEnterKey.AutoEllipsis = true;
            this.numEnterKey.BackColor = System.Drawing.Color.Gainsboro;
            this.numEnterKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numEnterKey.Location = new System.Drawing.Point(1179, 252);
            this.numEnterKey.Name = "numEnterKey";
            this.numEnterKey.Size = new System.Drawing.Size(48, 105);
            this.numEnterKey.TabIndex = 42;
            this.numEnterKey.Tag = "NumPadReturn";
            this.numEnterKey.Text = "Enter";
            this.numEnterKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.numEnterKey.UseMnemonic = false;
            this.numEnterKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key29
            // 
            this.key29.AutoEllipsis = true;
            this.key29.BackColor = System.Drawing.Color.Gainsboro;
            this.key29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key29.Location = new System.Drawing.Point(9, 81);
            this.key29.Name = "key29";
            this.key29.Size = new System.Drawing.Size(48, 48);
            this.key29.TabIndex = 43;
            this.key29.Tag = "=29";
            this.key29.Text = "~\r\n`";
            this.key29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key29.UseMnemonic = false;
            this.key29.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key2
            // 
            this.key2.AutoEllipsis = true;
            this.key2.BackColor = System.Drawing.Color.Gainsboro;
            this.key2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key2.Location = new System.Drawing.Point(63, 81);
            this.key2.Name = "key2";
            this.key2.Size = new System.Drawing.Size(48, 48);
            this.key2.TabIndex = 44;
            this.key2.Tag = "=02";
            this.key2.Text = "!\r\n1";
            this.key2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key2.UseMnemonic = false;
            this.key2.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key3
            // 
            this.key3.AutoEllipsis = true;
            this.key3.BackColor = System.Drawing.Color.Gainsboro;
            this.key3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key3.Location = new System.Drawing.Point(117, 81);
            this.key3.Name = "key3";
            this.key3.Size = new System.Drawing.Size(48, 48);
            this.key3.TabIndex = 45;
            this.key3.Tag = "=03";
            this.key3.Text = "@\r\n2";
            this.key3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key3.UseMnemonic = false;
            this.key3.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key4
            // 
            this.key4.AutoEllipsis = true;
            this.key4.BackColor = System.Drawing.Color.Gainsboro;
            this.key4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key4.Location = new System.Drawing.Point(171, 81);
            this.key4.Name = "key4";
            this.key4.Size = new System.Drawing.Size(48, 48);
            this.key4.TabIndex = 46;
            this.key4.Tag = "=04";
            this.key4.Text = "#\r\n3";
            this.key4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key4.UseMnemonic = false;
            this.key4.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key5
            // 
            this.key5.AutoEllipsis = true;
            this.key5.BackColor = System.Drawing.Color.Gainsboro;
            this.key5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key5.Location = new System.Drawing.Point(225, 81);
            this.key5.Name = "key5";
            this.key5.Size = new System.Drawing.Size(48, 48);
            this.key5.TabIndex = 47;
            this.key5.Tag = "=05";
            this.key5.Text = "$\r\n4";
            this.key5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key5.UseMnemonic = false;
            this.key5.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key6
            // 
            this.key6.AutoEllipsis = true;
            this.key6.BackColor = System.Drawing.Color.Gainsboro;
            this.key6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key6.Location = new System.Drawing.Point(279, 81);
            this.key6.Name = "key6";
            this.key6.Size = new System.Drawing.Size(48, 48);
            this.key6.TabIndex = 48;
            this.key6.Tag = "=06";
            this.key6.Text = "%\r\n5";
            this.key6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key6.UseMnemonic = false;
            this.key6.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key7
            // 
            this.key7.AutoEllipsis = true;
            this.key7.BackColor = System.Drawing.Color.Gainsboro;
            this.key7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key7.Location = new System.Drawing.Point(333, 81);
            this.key7.Name = "key7";
            this.key7.Size = new System.Drawing.Size(48, 48);
            this.key7.TabIndex = 49;
            this.key7.Tag = "=07";
            this.key7.Text = "^\r\n6";
            this.key7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key7.UseMnemonic = false;
            this.key7.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key8
            // 
            this.key8.AutoEllipsis = true;
            this.key8.BackColor = System.Drawing.Color.Gainsboro;
            this.key8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key8.Location = new System.Drawing.Point(387, 81);
            this.key8.Name = "key8";
            this.key8.Size = new System.Drawing.Size(48, 48);
            this.key8.TabIndex = 50;
            this.key8.Tag = "=08";
            this.key8.Text = "&\r\n7";
            this.key8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key8.UseMnemonic = false;
            this.key8.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key9
            // 
            this.key9.AutoEllipsis = true;
            this.key9.BackColor = System.Drawing.Color.Gainsboro;
            this.key9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key9.Location = new System.Drawing.Point(441, 81);
            this.key9.Name = "key9";
            this.key9.Size = new System.Drawing.Size(48, 48);
            this.key9.TabIndex = 51;
            this.key9.Tag = "=09";
            this.key9.Text = "*\r\n8";
            this.key9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key9.UseMnemonic = false;
            this.key9.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // keyA
            // 
            this.keyA.AutoEllipsis = true;
            this.keyA.BackColor = System.Drawing.Color.Gainsboro;
            this.keyA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.keyA.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keyA.Location = new System.Drawing.Point(495, 81);
            this.keyA.Name = "keyA";
            this.keyA.Size = new System.Drawing.Size(48, 48);
            this.keyA.TabIndex = 52;
            this.keyA.Tag = "=0A";
            this.keyA.Text = "(\r\n9";
            this.keyA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.keyA.UseMnemonic = false;
            this.keyA.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // keyC
            // 
            this.keyC.AutoEllipsis = true;
            this.keyC.BackColor = System.Drawing.Color.Gainsboro;
            this.keyC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.keyC.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keyC.Location = new System.Drawing.Point(603, 81);
            this.keyC.Name = "keyC";
            this.keyC.Size = new System.Drawing.Size(48, 48);
            this.keyC.TabIndex = 53;
            this.keyC.Tag = "=0C";
            this.keyC.Text = "_\r\n-";
            this.keyC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.keyC.UseMnemonic = false;
            this.keyC.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // keyD
            // 
            this.keyD.AutoEllipsis = true;
            this.keyD.BackColor = System.Drawing.Color.Gainsboro;
            this.keyD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.keyD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keyD.Location = new System.Drawing.Point(657, 81);
            this.keyD.Name = "keyD";
            this.keyD.Size = new System.Drawing.Size(48, 48);
            this.keyD.TabIndex = 54;
            this.keyD.Tag = "=0D";
            this.keyD.Text = "+\r\n=";
            this.keyD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.keyD.UseMnemonic = false;
            this.keyD.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // backSpaceKey
            // 
            this.backSpaceKey.AutoEllipsis = true;
            this.backSpaceKey.BackColor = System.Drawing.Color.Gainsboro;
            this.backSpaceKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.backSpaceKey.Location = new System.Drawing.Point(711, 81);
            this.backSpaceKey.Name = "backSpaceKey";
            this.backSpaceKey.Size = new System.Drawing.Size(86, 48);
            this.backSpaceKey.TabIndex = 55;
            this.backSpaceKey.Tag = "Back";
            this.backSpaceKey.Text = "Backspace";
            this.backSpaceKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.backSpaceKey.UseMnemonic = false;
            this.backSpaceKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // tabKey
            // 
            this.tabKey.AutoEllipsis = true;
            this.tabKey.BackColor = System.Drawing.Color.Gainsboro;
            this.tabKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabKey.Location = new System.Drawing.Point(9, 138);
            this.tabKey.Name = "tabKey";
            this.tabKey.Size = new System.Drawing.Size(86, 48);
            this.tabKey.TabIndex = 56;
            this.tabKey.Tag = "Tab";
            this.tabKey.Text = "Tab";
            this.tabKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.tabKey.UseMnemonic = false;
            this.tabKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key10
            // 
            this.key10.AutoEllipsis = true;
            this.key10.BackColor = System.Drawing.Color.Gainsboro;
            this.key10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key10.Location = new System.Drawing.Point(101, 138);
            this.key10.Name = "key10";
            this.key10.Size = new System.Drawing.Size(48, 48);
            this.key10.TabIndex = 57;
            this.key10.Tag = "=10";
            this.key10.Text = "Q";
            this.key10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key10.UseMnemonic = false;
            this.key10.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key11
            // 
            this.key11.AutoEllipsis = true;
            this.key11.BackColor = System.Drawing.Color.Gainsboro;
            this.key11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key11.Location = new System.Drawing.Point(155, 138);
            this.key11.Name = "key11";
            this.key11.Size = new System.Drawing.Size(48, 48);
            this.key11.TabIndex = 58;
            this.key11.Tag = "=11";
            this.key11.Text = "W";
            this.key11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key11.UseMnemonic = false;
            this.key11.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key12
            // 
            this.key12.AutoEllipsis = true;
            this.key12.BackColor = System.Drawing.Color.Gainsboro;
            this.key12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key12.Location = new System.Drawing.Point(209, 138);
            this.key12.Name = "key12";
            this.key12.Size = new System.Drawing.Size(48, 48);
            this.key12.TabIndex = 59;
            this.key12.Tag = "=12";
            this.key12.Text = "E";
            this.key12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key12.UseMnemonic = false;
            this.key12.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key13
            // 
            this.key13.AutoEllipsis = true;
            this.key13.BackColor = System.Drawing.Color.Gainsboro;
            this.key13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key13.Location = new System.Drawing.Point(263, 138);
            this.key13.Name = "key13";
            this.key13.Size = new System.Drawing.Size(48, 48);
            this.key13.TabIndex = 60;
            this.key13.Tag = "=13";
            this.key13.Text = "R";
            this.key13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key13.UseMnemonic = false;
            this.key13.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key14
            // 
            this.key14.AutoEllipsis = true;
            this.key14.BackColor = System.Drawing.Color.Gainsboro;
            this.key14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key14.Location = new System.Drawing.Point(317, 138);
            this.key14.Name = "key14";
            this.key14.Size = new System.Drawing.Size(48, 48);
            this.key14.TabIndex = 61;
            this.key14.Tag = "=14";
            this.key14.Text = "T";
            this.key14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key14.UseMnemonic = false;
            this.key14.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key15
            // 
            this.key15.AutoEllipsis = true;
            this.key15.BackColor = System.Drawing.Color.Gainsboro;
            this.key15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key15.Location = new System.Drawing.Point(371, 138);
            this.key15.Name = "key15";
            this.key15.Size = new System.Drawing.Size(48, 48);
            this.key15.TabIndex = 62;
            this.key15.Tag = "=15";
            this.key15.Text = "Y";
            this.key15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key15.UseMnemonic = false;
            this.key15.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key16
            // 
            this.key16.AutoEllipsis = true;
            this.key16.BackColor = System.Drawing.Color.Gainsboro;
            this.key16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key16.Location = new System.Drawing.Point(425, 138);
            this.key16.Name = "key16";
            this.key16.Size = new System.Drawing.Size(48, 48);
            this.key16.TabIndex = 63;
            this.key16.Tag = "=16";
            this.key16.Text = "U";
            this.key16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key16.UseMnemonic = false;
            this.key16.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key17
            // 
            this.key17.AutoEllipsis = true;
            this.key17.BackColor = System.Drawing.Color.Gainsboro;
            this.key17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key17.Location = new System.Drawing.Point(479, 138);
            this.key17.Name = "key17";
            this.key17.Size = new System.Drawing.Size(48, 48);
            this.key17.TabIndex = 64;
            this.key17.Tag = "=17";
            this.key17.Text = "I";
            this.key17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key17.UseMnemonic = false;
            this.key17.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key18
            // 
            this.key18.AutoEllipsis = true;
            this.key18.BackColor = System.Drawing.Color.Gainsboro;
            this.key18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key18.Location = new System.Drawing.Point(533, 138);
            this.key18.Name = "key18";
            this.key18.Size = new System.Drawing.Size(48, 48);
            this.key18.TabIndex = 65;
            this.key18.Tag = "=18";
            this.key18.Text = "O";
            this.key18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key18.UseMnemonic = false;
            this.key18.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key19
            // 
            this.key19.AutoEllipsis = true;
            this.key19.BackColor = System.Drawing.Color.Gainsboro;
            this.key19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key19.Location = new System.Drawing.Point(587, 138);
            this.key19.Name = "key19";
            this.key19.Size = new System.Drawing.Size(48, 48);
            this.key19.TabIndex = 66;
            this.key19.Tag = "=19";
            this.key19.Text = "P";
            this.key19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key19.UseMnemonic = false;
            this.key19.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key1A
            // 
            this.key1A.AutoEllipsis = true;
            this.key1A.BackColor = System.Drawing.Color.Gainsboro;
            this.key1A.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key1A.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key1A.Location = new System.Drawing.Point(641, 138);
            this.key1A.Name = "key1A";
            this.key1A.Size = new System.Drawing.Size(48, 48);
            this.key1A.TabIndex = 67;
            this.key1A.Tag = "=1A";
            this.key1A.Text = "{\r\n[";
            this.key1A.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key1A.UseMnemonic = false;
            this.key1A.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key1B
            // 
            this.key1B.AutoEllipsis = true;
            this.key1B.BackColor = System.Drawing.Color.Gainsboro;
            this.key1B.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key1B.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key1B.Location = new System.Drawing.Point(695, 138);
            this.key1B.Name = "key1B";
            this.key1B.Size = new System.Drawing.Size(48, 48);
            this.key1B.TabIndex = 68;
            this.key1B.Tag = "=1B";
            this.key1B.Text = "}\r\n]";
            this.key1B.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key1B.UseMnemonic = false;
            this.key1B.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key2B
            // 
            this.key2B.AutoEllipsis = true;
            this.key2B.BackColor = System.Drawing.Color.Gainsboro;
            this.key2B.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key2B.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key2B.Location = new System.Drawing.Point(749, 138);
            this.key2B.Name = "key2B";
            this.key2B.Size = new System.Drawing.Size(48, 48);
            this.key2B.TabIndex = 69;
            this.key2B.Tag = "=2B";
            this.key2B.Text = "|\r\n\\";
            this.key2B.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key2B.UseMnemonic = false;
            this.key2B.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // keyB
            // 
            this.keyB.AutoEllipsis = true;
            this.keyB.BackColor = System.Drawing.Color.Gainsboro;
            this.keyB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.keyB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keyB.Location = new System.Drawing.Point(549, 81);
            this.keyB.Name = "keyB";
            this.keyB.Size = new System.Drawing.Size(48, 48);
            this.keyB.TabIndex = 70;
            this.keyB.Tag = "=0B";
            this.keyB.Text = ")\r\n0";
            this.keyB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.keyB.UseMnemonic = false;
            this.keyB.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key28
            // 
            this.key28.AutoEllipsis = true;
            this.key28.BackColor = System.Drawing.Color.Gainsboro;
            this.key28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key28.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key28.Location = new System.Drawing.Point(653, 195);
            this.key28.Name = "key28";
            this.key28.Size = new System.Drawing.Size(48, 48);
            this.key28.TabIndex = 81;
            this.key28.Tag = "=28";
            this.key28.Text = "\"\r\n\'";
            this.key28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key28.UseMnemonic = false;
            this.key28.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key27
            // 
            this.key27.AutoEllipsis = true;
            this.key27.BackColor = System.Drawing.Color.Gainsboro;
            this.key27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key27.Location = new System.Drawing.Point(599, 195);
            this.key27.Name = "key27";
            this.key27.Size = new System.Drawing.Size(48, 48);
            this.key27.TabIndex = 80;
            this.key27.Tag = "=27";
            this.key27.Text = ":\r\n;";
            this.key27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key27.UseMnemonic = false;
            this.key27.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key26
            // 
            this.key26.AutoEllipsis = true;
            this.key26.BackColor = System.Drawing.Color.Gainsboro;
            this.key26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key26.Location = new System.Drawing.Point(545, 195);
            this.key26.Name = "key26";
            this.key26.Size = new System.Drawing.Size(48, 48);
            this.key26.TabIndex = 79;
            this.key26.Tag = "=26";
            this.key26.Text = "L";
            this.key26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key26.UseMnemonic = false;
            this.key26.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key25
            // 
            this.key25.AutoEllipsis = true;
            this.key25.BackColor = System.Drawing.Color.Gainsboro;
            this.key25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key25.Location = new System.Drawing.Point(491, 195);
            this.key25.Name = "key25";
            this.key25.Size = new System.Drawing.Size(48, 48);
            this.key25.TabIndex = 78;
            this.key25.Tag = "=25";
            this.key25.Text = "K";
            this.key25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key25.UseMnemonic = false;
            this.key25.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key24
            // 
            this.key24.AutoEllipsis = true;
            this.key24.BackColor = System.Drawing.Color.Gainsboro;
            this.key24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key24.Location = new System.Drawing.Point(437, 195);
            this.key24.Name = "key24";
            this.key24.Size = new System.Drawing.Size(48, 48);
            this.key24.TabIndex = 77;
            this.key24.Tag = "=24";
            this.key24.Text = "J";
            this.key24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key24.UseMnemonic = false;
            this.key24.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key23
            // 
            this.key23.AutoEllipsis = true;
            this.key23.BackColor = System.Drawing.Color.Gainsboro;
            this.key23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key23.Location = new System.Drawing.Point(383, 195);
            this.key23.Name = "key23";
            this.key23.Size = new System.Drawing.Size(48, 48);
            this.key23.TabIndex = 76;
            this.key23.Tag = "=23";
            this.key23.Text = "H";
            this.key23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key23.UseMnemonic = false;
            this.key23.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key22
            // 
            this.key22.AutoEllipsis = true;
            this.key22.BackColor = System.Drawing.Color.Gainsboro;
            this.key22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key22.Location = new System.Drawing.Point(329, 195);
            this.key22.Name = "key22";
            this.key22.Size = new System.Drawing.Size(48, 48);
            this.key22.TabIndex = 75;
            this.key22.Tag = "=22";
            this.key22.Text = "G";
            this.key22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key22.UseMnemonic = false;
            this.key22.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key21
            // 
            this.key21.AutoEllipsis = true;
            this.key21.BackColor = System.Drawing.Color.Gainsboro;
            this.key21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key21.Location = new System.Drawing.Point(275, 195);
            this.key21.Name = "key21";
            this.key21.Size = new System.Drawing.Size(48, 48);
            this.key21.TabIndex = 74;
            this.key21.Tag = "=21";
            this.key21.Text = "F";
            this.key21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key21.UseMnemonic = false;
            this.key21.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key20
            // 
            this.key20.AutoEllipsis = true;
            this.key20.BackColor = System.Drawing.Color.Gainsboro;
            this.key20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key20.Location = new System.Drawing.Point(221, 195);
            this.key20.Name = "key20";
            this.key20.Size = new System.Drawing.Size(48, 48);
            this.key20.TabIndex = 73;
            this.key20.Tag = "=20";
            this.key20.Text = "D";
            this.key20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key20.UseMnemonic = false;
            this.key20.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key1F
            // 
            this.key1F.AutoEllipsis = true;
            this.key1F.BackColor = System.Drawing.Color.Gainsboro;
            this.key1F.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key1F.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key1F.Location = new System.Drawing.Point(167, 195);
            this.key1F.Name = "key1F";
            this.key1F.Size = new System.Drawing.Size(48, 48);
            this.key1F.TabIndex = 72;
            this.key1F.Tag = "=1F";
            this.key1F.Text = "S";
            this.key1F.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key1F.UseMnemonic = false;
            this.key1F.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key1E
            // 
            this.key1E.AutoEllipsis = true;
            this.key1E.BackColor = System.Drawing.Color.Gainsboro;
            this.key1E.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key1E.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key1E.Location = new System.Drawing.Point(113, 195);
            this.key1E.Name = "key1E";
            this.key1E.Size = new System.Drawing.Size(48, 48);
            this.key1E.TabIndex = 71;
            this.key1E.Tag = "=1E";
            this.key1E.Text = "A";
            this.key1E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key1E.UseMnemonic = false;
            this.key1E.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // capsLockKey
            // 
            this.capsLockKey.AutoEllipsis = true;
            this.capsLockKey.BackColor = System.Drawing.Color.Gainsboro;
            this.capsLockKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.capsLockKey.Location = new System.Drawing.Point(9, 195);
            this.capsLockKey.Name = "capsLockKey";
            this.capsLockKey.Size = new System.Drawing.Size(98, 48);
            this.capsLockKey.TabIndex = 82;
            this.capsLockKey.Tag = "Capital";
            this.capsLockKey.Text = "Caps Lock";
            this.capsLockKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.capsLockKey.UseMnemonic = false;
            this.capsLockKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // enterKey
            // 
            this.enterKey.AutoEllipsis = true;
            this.enterKey.BackColor = System.Drawing.Color.Gainsboro;
            this.enterKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.enterKey.Location = new System.Drawing.Point(707, 195);
            this.enterKey.Name = "enterKey";
            this.enterKey.Size = new System.Drawing.Size(90, 48);
            this.enterKey.TabIndex = 83;
            this.enterKey.Tag = "Return";
            this.enterKey.Text = "Enter";
            this.enterKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.enterKey.UseMnemonic = false;
            this.enterKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key35
            // 
            this.key35.AutoEllipsis = true;
            this.key35.BackColor = System.Drawing.Color.Gainsboro;
            this.key35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key35.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key35.Location = new System.Drawing.Point(640, 252);
            this.key35.Name = "key35";
            this.key35.Size = new System.Drawing.Size(48, 48);
            this.key35.TabIndex = 93;
            this.key35.Tag = "=35";
            this.key35.Text = "?\r\n/";
            this.key35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key35.UseMnemonic = false;
            this.key35.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key34
            // 
            this.key34.AutoEllipsis = true;
            this.key34.BackColor = System.Drawing.Color.Gainsboro;
            this.key34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key34.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key34.Location = new System.Drawing.Point(586, 252);
            this.key34.Name = "key34";
            this.key34.Size = new System.Drawing.Size(48, 48);
            this.key34.TabIndex = 92;
            this.key34.Tag = "=34";
            this.key34.Text = ">\r\n.";
            this.key34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key34.UseMnemonic = false;
            this.key34.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key33
            // 
            this.key33.AutoEllipsis = true;
            this.key33.BackColor = System.Drawing.Color.Gainsboro;
            this.key33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key33.Location = new System.Drawing.Point(532, 252);
            this.key33.Name = "key33";
            this.key33.Size = new System.Drawing.Size(48, 48);
            this.key33.TabIndex = 91;
            this.key33.Tag = "=33";
            this.key33.Text = "<\r\n,";
            this.key33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key33.UseMnemonic = false;
            this.key33.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key32
            // 
            this.key32.AutoEllipsis = true;
            this.key32.BackColor = System.Drawing.Color.Gainsboro;
            this.key32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key32.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key32.Location = new System.Drawing.Point(478, 252);
            this.key32.Name = "key32";
            this.key32.Size = new System.Drawing.Size(48, 48);
            this.key32.TabIndex = 90;
            this.key32.Tag = "=32";
            this.key32.Text = "M";
            this.key32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key32.UseMnemonic = false;
            this.key32.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key31
            // 
            this.key31.AutoEllipsis = true;
            this.key31.BackColor = System.Drawing.Color.Gainsboro;
            this.key31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key31.Location = new System.Drawing.Point(424, 252);
            this.key31.Name = "key31";
            this.key31.Size = new System.Drawing.Size(48, 48);
            this.key31.TabIndex = 89;
            this.key31.Tag = "=31";
            this.key31.Text = "N";
            this.key31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key31.UseMnemonic = false;
            this.key31.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key30
            // 
            this.key30.AutoEllipsis = true;
            this.key30.BackColor = System.Drawing.Color.Gainsboro;
            this.key30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key30.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key30.Location = new System.Drawing.Point(370, 252);
            this.key30.Name = "key30";
            this.key30.Size = new System.Drawing.Size(48, 48);
            this.key30.TabIndex = 88;
            this.key30.Tag = "=30";
            this.key30.Text = "B";
            this.key30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key30.UseMnemonic = false;
            this.key30.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key2F
            // 
            this.key2F.AutoEllipsis = true;
            this.key2F.BackColor = System.Drawing.Color.Gainsboro;
            this.key2F.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key2F.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key2F.Location = new System.Drawing.Point(316, 252);
            this.key2F.Name = "key2F";
            this.key2F.Size = new System.Drawing.Size(48, 48);
            this.key2F.TabIndex = 87;
            this.key2F.Tag = "=2F";
            this.key2F.Text = "V";
            this.key2F.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key2F.UseMnemonic = false;
            this.key2F.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key2E
            // 
            this.key2E.AutoEllipsis = true;
            this.key2E.BackColor = System.Drawing.Color.Gainsboro;
            this.key2E.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key2E.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key2E.Location = new System.Drawing.Point(262, 252);
            this.key2E.Name = "key2E";
            this.key2E.Size = new System.Drawing.Size(48, 48);
            this.key2E.TabIndex = 86;
            this.key2E.Tag = "=2E";
            this.key2E.Text = "C";
            this.key2E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key2E.UseMnemonic = false;
            this.key2E.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key2D
            // 
            this.key2D.AutoEllipsis = true;
            this.key2D.BackColor = System.Drawing.Color.Gainsboro;
            this.key2D.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key2D.Location = new System.Drawing.Point(208, 252);
            this.key2D.Name = "key2D";
            this.key2D.Size = new System.Drawing.Size(48, 48);
            this.key2D.TabIndex = 85;
            this.key2D.Tag = "=2D";
            this.key2D.Text = "X";
            this.key2D.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key2D.UseMnemonic = false;
            this.key2D.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // key2C
            // 
            this.key2C.AutoEllipsis = true;
            this.key2C.BackColor = System.Drawing.Color.Gainsboro;
            this.key2C.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key2C.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key2C.Location = new System.Drawing.Point(154, 252);
            this.key2C.Name = "key2C";
            this.key2C.Size = new System.Drawing.Size(48, 48);
            this.key2C.TabIndex = 84;
            this.key2C.Tag = "=2C";
            this.key2C.Text = "Z";
            this.key2C.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key2C.UseMnemonic = false;
            this.key2C.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // leftShiftKey
            // 
            this.leftShiftKey.AutoEllipsis = true;
            this.leftShiftKey.BackColor = System.Drawing.Color.Gainsboro;
            this.leftShiftKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.leftShiftKey.Location = new System.Drawing.Point(9, 252);
            this.leftShiftKey.Name = "leftShiftKey";
            this.leftShiftKey.Size = new System.Drawing.Size(86, 48);
            this.leftShiftKey.TabIndex = 94;
            this.leftShiftKey.Tag = "LShiftKey";
            this.leftShiftKey.Text = "Shift";
            this.leftShiftKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.leftShiftKey.UseMnemonic = false;
            this.leftShiftKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // rightShiftKey
            // 
            this.rightShiftKey.AutoEllipsis = true;
            this.rightShiftKey.BackColor = System.Drawing.Color.Gainsboro;
            this.rightShiftKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rightShiftKey.Location = new System.Drawing.Point(695, 252);
            this.rightShiftKey.Name = "rightShiftKey";
            this.rightShiftKey.Size = new System.Drawing.Size(102, 48);
            this.rightShiftKey.TabIndex = 95;
            this.rightShiftKey.Tag = "RShiftKey";
            this.rightShiftKey.Text = "Shift";
            this.rightShiftKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rightShiftKey.UseMnemonic = false;
            this.rightShiftKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // leftWinKey
            // 
            this.leftWinKey.AutoEllipsis = true;
            this.leftWinKey.BackColor = System.Drawing.Color.Gainsboro;
            this.leftWinKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.leftWinKey.Location = new System.Drawing.Point(101, 309);
            this.leftWinKey.Name = "leftWinKey";
            this.leftWinKey.Size = new System.Drawing.Size(48, 48);
            this.leftWinKey.TabIndex = 97;
            this.leftWinKey.Tag = "LWin";
            this.leftWinKey.Text = "Win";
            this.leftWinKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.leftWinKey.UseMnemonic = false;
            this.leftWinKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // leftAltKey
            // 
            this.leftAltKey.AutoEllipsis = true;
            this.leftAltKey.BackColor = System.Drawing.Color.Gainsboro;
            this.leftAltKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.leftAltKey.Location = new System.Drawing.Point(155, 309);
            this.leftAltKey.Name = "leftAltKey";
            this.leftAltKey.Size = new System.Drawing.Size(48, 48);
            this.leftAltKey.TabIndex = 98;
            this.leftAltKey.Tag = "LMenu";
            this.leftAltKey.Text = "Alt";
            this.leftAltKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.leftAltKey.UseMnemonic = false;
            this.leftAltKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // rightAltKey
            // 
            this.rightAltKey.AutoEllipsis = true;
            this.rightAltKey.BackColor = System.Drawing.Color.Gainsboro;
            this.rightAltKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rightAltKey.Location = new System.Drawing.Point(549, 309);
            this.rightAltKey.Name = "rightAltKey";
            this.rightAltKey.Size = new System.Drawing.Size(48, 48);
            this.rightAltKey.TabIndex = 99;
            this.rightAltKey.Tag = "RMenu";
            this.rightAltKey.Text = "Alt";
            this.rightAltKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rightAltKey.UseMnemonic = false;
            this.rightAltKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // appsKey
            // 
            this.appsKey.AutoEllipsis = true;
            this.appsKey.BackColor = System.Drawing.Color.Gainsboro;
            this.appsKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.appsKey.Location = new System.Drawing.Point(657, 309);
            this.appsKey.Name = "appsKey";
            this.appsKey.Size = new System.Drawing.Size(48, 48);
            this.appsKey.TabIndex = 100;
            this.appsKey.Tag = "Apps";
            this.appsKey.Text = "Apps";
            this.appsKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.appsKey.UseMnemonic = false;
            this.appsKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // rightCtrlKey
            // 
            this.rightCtrlKey.AutoEllipsis = true;
            this.rightCtrlKey.BackColor = System.Drawing.Color.Gainsboro;
            this.rightCtrlKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rightCtrlKey.Location = new System.Drawing.Point(711, 309);
            this.rightCtrlKey.Name = "rightCtrlKey";
            this.rightCtrlKey.Size = new System.Drawing.Size(86, 48);
            this.rightCtrlKey.TabIndex = 101;
            this.rightCtrlKey.Tag = "RControlKey";
            this.rightCtrlKey.Text = "Ctrl";
            this.rightCtrlKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rightCtrlKey.UseMnemonic = false;
            this.rightCtrlKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // leftCtrlKey
            // 
            this.leftCtrlKey.AutoEllipsis = true;
            this.leftCtrlKey.BackColor = System.Drawing.Color.Gainsboro;
            this.leftCtrlKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.leftCtrlKey.Location = new System.Drawing.Point(9, 309);
            this.leftCtrlKey.Name = "leftCtrlKey";
            this.leftCtrlKey.Size = new System.Drawing.Size(86, 48);
            this.leftCtrlKey.TabIndex = 102;
            this.leftCtrlKey.Tag = "LControlKey";
            this.leftCtrlKey.Text = "Ctrl";
            this.leftCtrlKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.leftCtrlKey.UseMnemonic = false;
            this.leftCtrlKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // spaceBar
            // 
            this.spaceBar.AutoEllipsis = true;
            this.spaceBar.BackColor = System.Drawing.Color.Gainsboro;
            this.spaceBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceBar.Location = new System.Drawing.Point(209, 309);
            this.spaceBar.Name = "spaceBar";
            this.spaceBar.Size = new System.Drawing.Size(334, 48);
            this.spaceBar.TabIndex = 103;
            this.spaceBar.Tag = "Space";
            this.spaceBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.spaceBar.UseMnemonic = false;
            this.spaceBar.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // labelsRadioButton
            // 
            this.labelsRadioButton.AutoSize = true;
            this.labelsRadioButton.Checked = true;
            this.labelsRadioButton.Location = new System.Drawing.Point(3, 3);
            this.labelsRadioButton.Name = "labelsRadioButton";
            this.labelsRadioButton.Size = new System.Drawing.Size(65, 19);
            this.labelsRadioButton.TabIndex = 104;
            this.labelsRadioButton.TabStop = true;
            this.labelsRadioButton.Tag = "Labels";
            this.labelsRadioButton.Text = "Labels";
            this.labelsRadioButton.UseVisualStyleBackColor = true;
            this.labelsRadioButton.CheckedChanged += new System.EventHandler(this.DisplayCheckedChanged);
            this.labelsRadioButton.Enter += new System.EventHandler(this.KeyboardMap_Enter);
            // 
            // keyNamesRadioButton
            // 
            this.keyNamesRadioButton.AutoSize = true;
            this.keyNamesRadioButton.Location = new System.Drawing.Point(101, 3);
            this.keyNamesRadioButton.Name = "keyNamesRadioButton";
            this.keyNamesRadioButton.Size = new System.Drawing.Size(84, 19);
            this.keyNamesRadioButton.TabIndex = 105;
            this.keyNamesRadioButton.Tag = "Names";
            this.keyNamesRadioButton.Text = "Key codes";
            this.keyNamesRadioButton.UseVisualStyleBackColor = true;
            this.keyNamesRadioButton.CheckedChanged += new System.EventHandler(this.DisplayCheckedChanged);
            this.keyNamesRadioButton.Enter += new System.EventHandler(this.KeyboardMap_Enter);
            // 
            // definitionsRadioButton
            // 
            this.definitionsRadioButton.AutoSize = true;
            this.definitionsRadioButton.Location = new System.Drawing.Point(101, 28);
            this.definitionsRadioButton.Name = "definitionsRadioButton";
            this.definitionsRadioButton.Size = new System.Drawing.Size(124, 19);
            this.definitionsRadioButton.TabIndex = 106;
            this.definitionsRadioButton.Tag = "Definitions";
            this.definitionsRadioButton.Text = "wx3270 definition";
            this.definitionsRadioButton.UseVisualStyleBackColor = true;
            this.definitionsRadioButton.CheckedChanged += new System.EventHandler(this.DisplayCheckedChanged);
            this.definitionsRadioButton.Enter += new System.EventHandler(this.KeyboardMap_Enter);
            // 
            // numLockCheckBox
            // 
            this.numLockCheckBox.AutoSize = true;
            this.modifiersTable.SetColumnSpan(this.numLockCheckBox, 2);
            this.numLockCheckBox.Location = new System.Drawing.Point(3, 28);
            this.numLockCheckBox.Name = "numLockCheckBox";
            this.numLockCheckBox.Size = new System.Drawing.Size(85, 19);
            this.numLockCheckBox.TabIndex = 107;
            this.numLockCheckBox.TabStop = false;
            this.numLockCheckBox.Text = "Num Lock";
            this.numLockCheckBox.UseVisualStyleBackColor = true;
            this.numLockCheckBox.CheckStateChanged += new System.EventHandler(this.NumLockChanged);
            this.numLockCheckBox.Enter += new System.EventHandler(this.KeyboardMap_Enter);
            // 
            // shiftCheckBox
            // 
            this.shiftCheckBox.AutoSize = true;
            this.shiftCheckBox.Location = new System.Drawing.Point(3, 3);
            this.shiftCheckBox.Name = "shiftCheckBox";
            this.shiftCheckBox.Size = new System.Drawing.Size(53, 19);
            this.shiftCheckBox.TabIndex = 108;
            this.shiftCheckBox.TabStop = false;
            this.shiftCheckBox.Tag = "Shift";
            this.shiftCheckBox.Text = "Shift";
            this.shiftCheckBox.UseVisualStyleBackColor = true;
            this.shiftCheckBox.CheckedChanged += new System.EventHandler(this.ModifierCheckedChanged);
            this.shiftCheckBox.Enter += new System.EventHandler(this.KeyboardMap_Enter);
            // 
            // ctrlCheckBox
            // 
            this.ctrlCheckBox.AutoSize = true;
            this.ctrlCheckBox.Location = new System.Drawing.Point(62, 3);
            this.ctrlCheckBox.Name = "ctrlCheckBox";
            this.ctrlCheckBox.Size = new System.Drawing.Size(47, 19);
            this.ctrlCheckBox.TabIndex = 109;
            this.ctrlCheckBox.TabStop = false;
            this.ctrlCheckBox.Tag = "Ctrl";
            this.ctrlCheckBox.Text = "Ctrl";
            this.ctrlCheckBox.UseVisualStyleBackColor = true;
            this.ctrlCheckBox.CheckedChanged += new System.EventHandler(this.ModifierCheckedChanged);
            this.ctrlCheckBox.Enter += new System.EventHandler(this.KeyboardMap_Enter);
            // 
            // altCheckBox
            // 
            this.altCheckBox.AutoSize = true;
            this.altCheckBox.Location = new System.Drawing.Point(115, 3);
            this.altCheckBox.Name = "altCheckBox";
            this.altCheckBox.Size = new System.Drawing.Size(42, 19);
            this.altCheckBox.TabIndex = 110;
            this.altCheckBox.TabStop = false;
            this.altCheckBox.Tag = "Alt";
            this.altCheckBox.Text = "Alt";
            this.altCheckBox.UseVisualStyleBackColor = true;
            this.altCheckBox.CheckedChanged += new System.EventHandler(this.ModifierCheckedChanged);
            this.altCheckBox.Enter += new System.EventHandler(this.KeyboardMap_Enter);
            // 
            // displayGroupBox
            // 
            this.displayGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.displayGroupBox.AutoSize = true;
            this.displayGroupBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.displayGroupBox.Controls.Add(this.displayLayoutPanel);
            this.displayGroupBox.Controls.Add(this.displayTable);
            this.displayGroupBox.Location = new System.Drawing.Point(418, 3);
            this.displayGroupBox.Margin = new System.Windows.Forms.Padding(3, 3, 10, 3);
            this.displayGroupBox.Name = "displayGroupBox";
            this.displayGroupBox.Padding = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.displayGroupBox.Size = new System.Drawing.Size(244, 85);
            this.displayGroupBox.TabIndex = 111;
            this.displayGroupBox.TabStop = false;
            this.displayGroupBox.Text = "Display";
            // 
            // displayLayoutPanel
            // 
            this.displayLayoutPanel.AutoSize = true;
            this.displayLayoutPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.displayLayoutPanel.Location = new System.Drawing.Point(6, 18);
            this.displayLayoutPanel.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.displayLayoutPanel.Name = "displayLayoutPanel";
            this.displayLayoutPanel.Size = new System.Drawing.Size(0, 0);
            this.displayLayoutPanel.TabIndex = 121;
            // 
            // displayTable
            // 
            this.displayTable.AutoSize = true;
            this.displayTable.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.displayTable.ColumnCount = 2;
            this.displayTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.displayTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.displayTable.Controls.Add(this.definitionsRadioButton, 1, 1);
            this.displayTable.Controls.Add(this.scanCodesRadioButton, 0, 1);
            this.displayTable.Controls.Add(this.keyNamesRadioButton, 1, 0);
            this.displayTable.Controls.Add(this.labelsRadioButton, 0, 0);
            this.displayTable.Location = new System.Drawing.Point(10, 19);
            this.displayTable.Name = "displayTable";
            this.displayTable.RowCount = 2;
            this.displayTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.displayTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.displayTable.Size = new System.Drawing.Size(228, 50);
            this.displayTable.TabIndex = 116;
            // 
            // scanCodesRadioButton
            // 
            this.scanCodesRadioButton.AutoSize = true;
            this.scanCodesRadioButton.Location = new System.Drawing.Point(3, 28);
            this.scanCodesRadioButton.Name = "scanCodesRadioButton";
            this.scanCodesRadioButton.Size = new System.Drawing.Size(92, 19);
            this.scanCodesRadioButton.TabIndex = 107;
            this.scanCodesRadioButton.TabStop = true;
            this.scanCodesRadioButton.Tag = "ScanCodes";
            this.scanCodesRadioButton.Text = "Scan codes";
            this.scanCodesRadioButton.UseVisualStyleBackColor = true;
            this.scanCodesRadioButton.CheckedChanged += new System.EventHandler(this.DisplayCheckedChanged);
            // 
            // modifiersGroupBox
            // 
            this.modifiersGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.modifiersGroupBox.AutoSize = true;
            this.modifiersGroupBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.modifiersGroupBox.Controls.Add(this.modifiersLayoutPanel);
            this.modifiersGroupBox.Controls.Add(this.modifiersTable);
            this.modifiersGroupBox.Location = new System.Drawing.Point(682, 3);
            this.modifiersGroupBox.Margin = new System.Windows.Forms.Padding(10, 3, 10, 3);
            this.modifiersGroupBox.Name = "modifiersGroupBox";
            this.modifiersGroupBox.Padding = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.modifiersGroupBox.Size = new System.Drawing.Size(192, 84);
            this.modifiersGroupBox.TabIndex = 112;
            this.modifiersGroupBox.TabStop = false;
            this.modifiersGroupBox.Tag = "";
            this.modifiersGroupBox.Text = "Modifiers";
            // 
            // modifiersLayoutPanel
            // 
            this.modifiersLayoutPanel.AutoSize = true;
            this.modifiersLayoutPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.modifiersLayoutPanel.Location = new System.Drawing.Point(6, 18);
            this.modifiersLayoutPanel.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.modifiersLayoutPanel.Name = "modifiersLayoutPanel";
            this.modifiersLayoutPanel.Size = new System.Drawing.Size(0, 0);
            this.modifiersLayoutPanel.TabIndex = 121;
            // 
            // modifiersTable
            // 
            this.modifiersTable.AutoSize = true;
            this.modifiersTable.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.modifiersTable.ColumnCount = 3;
            this.modifiersTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.modifiersTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.modifiersTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.modifiersTable.Controls.Add(this.scrollLockCheckBox, 1, 1);
            this.modifiersTable.Controls.Add(this.numLockCheckBox, 0, 1);
            this.modifiersTable.Controls.Add(this.altCheckBox, 2, 0);
            this.modifiersTable.Controls.Add(this.ctrlCheckBox, 1, 0);
            this.modifiersTable.Controls.Add(this.shiftCheckBox, 0, 0);
            this.modifiersTable.Location = new System.Drawing.Point(17, 18);
            this.modifiersTable.Name = "modifiersTable";
            this.modifiersTable.RowCount = 2;
            this.modifiersTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.modifiersTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.modifiersTable.Size = new System.Drawing.Size(169, 50);
            this.modifiersTable.TabIndex = 116;
            // 
            // scrollLockCheckBox
            // 
            this.scrollLockCheckBox.AutoSize = true;
            this.scrollLockCheckBox.Location = new System.Drawing.Point(115, 28);
            this.scrollLockCheckBox.Name = "scrollLockCheckBox";
            this.scrollLockCheckBox.Size = new System.Drawing.Size(51, 19);
            this.scrollLockCheckBox.TabIndex = 111;
            this.scrollLockCheckBox.Tag = "Apl";
            this.scrollLockCheckBox.Text = "APL";
            this.scrollLockCheckBox.UseVisualStyleBackColor = true;
            this.scrollLockCheckBox.CheckedChanged += new System.EventHandler(this.ModifierCheckedChanged);
            // 
            // rightWinKey
            // 
            this.rightWinKey.AutoEllipsis = true;
            this.rightWinKey.BackColor = System.Drawing.Color.Gainsboro;
            this.rightWinKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rightWinKey.Location = new System.Drawing.Point(603, 309);
            this.rightWinKey.Name = "rightWinKey";
            this.rightWinKey.Size = new System.Drawing.Size(48, 48);
            this.rightWinKey.TabIndex = 113;
            this.rightWinKey.Tag = "RWin";
            this.rightWinKey.Text = "Win";
            this.rightWinKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rightWinKey.UseMnemonic = false;
            this.rightWinKey.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // noteLabel
            // 
            this.noteLabel.AutoSize = true;
            this.noteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noteLabel.Location = new System.Drawing.Point(1015, 44);
            this.noteLabel.Name = "noteLabel";
            this.noteLabel.Size = new System.Drawing.Size(217, 34);
            this.noteLabel.TabIndex = 114;
            this.noteLabel.Text = "Note: This is a generic keyboard.\r\nYour keyboard layout may differ.";
            // 
            // modeGroupBox
            // 
            this.modeGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.modeGroupBox.AutoSize = true;
            this.modeGroupBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.modeGroupBox.Controls.Add(this.modeLayoutPanel);
            this.modeGroupBox.Controls.Add(this.modeTable);
            this.modeGroupBox.Location = new System.Drawing.Point(894, 4);
            this.modeGroupBox.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.modeGroupBox.Name = "modeGroupBox";
            this.modeGroupBox.Padding = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.modeGroupBox.Size = new System.Drawing.Size(80, 82);
            this.modeGroupBox.TabIndex = 115;
            this.modeGroupBox.TabStop = false;
            this.modeGroupBox.Text = "Mode";
            // 
            // modeLayoutPanel
            // 
            this.modeLayoutPanel.AutoSize = true;
            this.modeLayoutPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.modeLayoutPanel.Location = new System.Drawing.Point(6, 18);
            this.modeLayoutPanel.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.modeLayoutPanel.Name = "modeLayoutPanel";
            this.modeLayoutPanel.Size = new System.Drawing.Size(0, 0);
            this.modeLayoutPanel.TabIndex = 121;
            // 
            // modeTable
            // 
            this.modeTable.AutoSize = true;
            this.modeTable.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.modeTable.ColumnCount = 1;
            this.modeTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.modeTable.Controls.Add(this.mode3270CheckBox, 0, 1);
            this.modeTable.Controls.Add(this.nvtModeCheckBox, 0, 0);
            this.modeTable.Location = new System.Drawing.Point(11, 16);
            this.modeTable.Name = "modeTable";
            this.modeTable.RowCount = 2;
            this.modeTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.modeTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.modeTable.Size = new System.Drawing.Size(63, 50);
            this.modeTable.TabIndex = 116;
            // 
            // mode3270CheckBox
            // 
            this.mode3270CheckBox.AutoSize = true;
            this.mode3270CheckBox.Location = new System.Drawing.Point(3, 28);
            this.mode3270CheckBox.Name = "mode3270CheckBox";
            this.mode3270CheckBox.Size = new System.Drawing.Size(57, 19);
            this.mode3270CheckBox.TabIndex = 117;
            this.mode3270CheckBox.Tag = "Mode3270";
            this.mode3270CheckBox.Text = "3270";
            this.mode3270CheckBox.UseVisualStyleBackColor = true;
            this.mode3270CheckBox.CheckedChanged += new System.EventHandler(this.ModeModifierCheckedChanged);
            // 
            // nvtModeCheckBox
            // 
            this.nvtModeCheckBox.AutoSize = true;
            this.nvtModeCheckBox.Location = new System.Drawing.Point(3, 3);
            this.nvtModeCheckBox.Name = "nvtModeCheckBox";
            this.nvtModeCheckBox.Size = new System.Drawing.Size(52, 19);
            this.nvtModeCheckBox.TabIndex = 116;
            this.nvtModeCheckBox.Tag = "ModeNvt";
            this.nvtModeCheckBox.Text = "NVT";
            this.nvtModeCheckBox.UseVisualStyleBackColor = true;
            this.nvtModeCheckBox.CheckedChanged += new System.EventHandler(this.ModeModifierCheckedChanged);
            // 
            // key56
            // 
            this.key56.AutoEllipsis = true;
            this.key56.BackColor = System.Drawing.Color.Gainsboro;
            this.key56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.key56.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.key56.Location = new System.Drawing.Point(101, 252);
            this.key56.Name = "key56";
            this.key56.Size = new System.Drawing.Size(48, 48);
            this.key56.TabIndex = 116;
            this.key56.Tag = "=56";
            this.key56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.key56.UseMnemonic = false;
            this.key56.Click += new System.EventHandler(this.KeyboardPicture_Click);
            // 
            // nativeNameLabel
            // 
            this.nativeNameLabel.AutoSize = true;
            this.nativeNameLabel.Location = new System.Drawing.Point(1015, 11);
            this.nativeNameLabel.Name = "nativeNameLabel";
            this.nativeNameLabel.Size = new System.Drawing.Size(82, 15);
            this.nativeNameLabel.TabIndex = 117;
            this.nativeNameLabel.Text = "`Native Name";
            // 
            // helpPictureBox
            // 
            this.helpPictureBox.ContextMenuStrip = this.helpContextMenuStrip;
            this.helpPictureBox.Image = global::Wx3270.Properties.Resources.Question23c;
            this.helpPictureBox.Location = new System.Drawing.Point(22, 423);
            this.helpPictureBox.Name = "helpPictureBox";
            this.helpPictureBox.Size = new System.Drawing.Size(24, 24);
            this.helpPictureBox.TabIndex = 123;
            this.helpPictureBox.TabStop = false;
            this.toolTip1.SetToolTip(this.helpPictureBox, "Get help");
            this.helpPictureBox.Click += new System.EventHandler(this.HelpClick);
            // 
            // helpContextMenuStrip
            // 
            this.helpContextMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.helpContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.displayHelpInBrowserToolStripMenuItem,
            this.startTourToolStripMenuItem});
            this.helpContextMenuStrip.Name = "helpContextMenuStrip";
            this.helpContextMenuStrip.Size = new System.Drawing.Size(234, 52);
            // 
            // displayHelpInBrowserToolStripMenuItem
            // 
            this.displayHelpInBrowserToolStripMenuItem.Name = "displayHelpInBrowserToolStripMenuItem";
            this.displayHelpInBrowserToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.displayHelpInBrowserToolStripMenuItem.Tag = "Help";
            this.displayHelpInBrowserToolStripMenuItem.Text = "Display help in browser";
            this.displayHelpInBrowserToolStripMenuItem.Click += new System.EventHandler(this.HelpMenuClick);
            // 
            // startTourToolStripMenuItem
            // 
            this.startTourToolStripMenuItem.Name = "startTourToolStripMenuItem";
            this.startTourToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.startTourToolStripMenuItem.Tag = "Tour";
            this.startTourToolStripMenuItem.Text = "Start tour";
            this.startTourToolStripMenuItem.Click += new System.EventHandler(this.HelpMenuClick);
            // 
            // aplLegendPanel
            // 
            this.aplLegendPanel.AutoSize = true;
            this.aplLegendPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.aplLegendPanel.BackColor = System.Drawing.Color.Silver;
            this.aplLegendPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aplLegendPanel.Controls.Add(this.aplShiftLabel);
            this.aplLegendPanel.Controls.Add(this.aplCtrlShiftLabel);
            this.aplLegendPanel.Controls.Add(this.aplNormalLabel);
            this.aplLegendPanel.Controls.Add(this.aplCtrlLabel);
            this.aplLegendPanel.Location = new System.Drawing.Point(112, 405);
            this.aplLegendPanel.Name = "aplLegendPanel";
            this.aplLegendPanel.Size = new System.Drawing.Size(112, 66);
            this.aplLegendPanel.TabIndex = 118;
            this.aplLegendPanel.Tag = "";
            this.aplLegendPanel.Visible = false;
            // 
            // aplShiftLabel
            // 
            this.aplShiftLabel.Location = new System.Drawing.Point(3, 0);
            this.aplShiftLabel.Name = "aplShiftLabel";
            this.aplShiftLabel.Size = new System.Drawing.Size(49, 32);
            this.aplShiftLabel.TabIndex = 0;
            this.aplShiftLabel.Text = "Shift";
            this.aplShiftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aplCtrlShiftLabel
            // 
            this.aplLegendPanel.SetFlowBreak(this.aplCtrlShiftLabel, true);
            this.aplCtrlShiftLabel.Location = new System.Drawing.Point(58, 0);
            this.aplCtrlShiftLabel.Name = "aplCtrlShiftLabel";
            this.aplCtrlShiftLabel.Size = new System.Drawing.Size(49, 32);
            this.aplCtrlShiftLabel.TabIndex = 1;
            this.aplCtrlShiftLabel.Text = "Alt+Shift";
            this.aplCtrlShiftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aplNormalLabel
            // 
            this.aplNormalLabel.Location = new System.Drawing.Point(3, 32);
            this.aplNormalLabel.Name = "aplNormalLabel";
            this.aplNormalLabel.Size = new System.Drawing.Size(49, 32);
            this.aplNormalLabel.TabIndex = 2;
            this.aplNormalLabel.Text = "Normal";
            this.aplNormalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aplCtrlLabel
            // 
            this.aplCtrlLabel.Location = new System.Drawing.Point(58, 32);
            this.aplCtrlLabel.Name = "aplCtrlLabel";
            this.aplCtrlLabel.Size = new System.Drawing.Size(49, 32);
            this.aplCtrlLabel.TabIndex = 3;
            this.aplCtrlLabel.Text = "Alt";
            this.aplCtrlLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aplLegendLabel
            // 
            this.aplLegendLabel.AutoSize = true;
            this.aplLegendLabel.Location = new System.Drawing.Point(56, 422);
            this.aplLegendLabel.Name = "aplLegendLabel";
            this.aplLegendLabel.Size = new System.Drawing.Size(49, 30);
            this.aplLegendLabel.TabIndex = 119;
            this.aplLegendLabel.Text = "APL\r\nLegend";
            this.aplLegendLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.aplLegendLabel.Visible = false;
            // 
            // keysPanel
            // 
            this.keysPanel.Controls.Add(this.layoutLabel);
            this.keysPanel.Controls.Add(this.escapeKey);
            this.keysPanel.Controls.Add(this.f1Key);
            this.keysPanel.Controls.Add(this.f2Key);
            this.keysPanel.Controls.Add(this.nativeNameLabel);
            this.keysPanel.Controls.Add(this.f3Key);
            this.keysPanel.Controls.Add(this.key56);
            this.keysPanel.Controls.Add(this.f4Key);
            this.keysPanel.Controls.Add(this.f5Key);
            this.keysPanel.Controls.Add(this.noteLabel);
            this.keysPanel.Controls.Add(this.f6Key);
            this.keysPanel.Controls.Add(this.rightWinKey);
            this.keysPanel.Controls.Add(this.f7Key);
            this.keysPanel.Controls.Add(this.f8Key);
            this.keysPanel.Controls.Add(this.f9Key);
            this.keysPanel.Controls.Add(this.spaceBar);
            this.keysPanel.Controls.Add(this.f10Key);
            this.keysPanel.Controls.Add(this.leftCtrlKey);
            this.keysPanel.Controls.Add(this.f11Key);
            this.keysPanel.Controls.Add(this.rightCtrlKey);
            this.keysPanel.Controls.Add(this.f12Key);
            this.keysPanel.Controls.Add(this.appsKey);
            this.keysPanel.Controls.Add(this.prtScnKey);
            this.keysPanel.Controls.Add(this.rightAltKey);
            this.keysPanel.Controls.Add(this.scrollLockKey);
            this.keysPanel.Controls.Add(this.leftAltKey);
            this.keysPanel.Controls.Add(this.pauseKey);
            this.keysPanel.Controls.Add(this.leftWinKey);
            this.keysPanel.Controls.Add(this.insertKey);
            this.keysPanel.Controls.Add(this.rightShiftKey);
            this.keysPanel.Controls.Add(this.homeKey);
            this.keysPanel.Controls.Add(this.leftShiftKey);
            this.keysPanel.Controls.Add(this.pageUpKey);
            this.keysPanel.Controls.Add(this.key35);
            this.keysPanel.Controls.Add(this.deleteKey);
            this.keysPanel.Controls.Add(this.key34);
            this.keysPanel.Controls.Add(this.endKey);
            this.keysPanel.Controls.Add(this.key33);
            this.keysPanel.Controls.Add(this.pageDownKey);
            this.keysPanel.Controls.Add(this.key32);
            this.keysPanel.Controls.Add(this.upKey);
            this.keysPanel.Controls.Add(this.key31);
            this.keysPanel.Controls.Add(this.leftKey);
            this.keysPanel.Controls.Add(this.key30);
            this.keysPanel.Controls.Add(this.downKey);
            this.keysPanel.Controls.Add(this.key2F);
            this.keysPanel.Controls.Add(this.rightKey);
            this.keysPanel.Controls.Add(this.key2E);
            this.keysPanel.Controls.Add(this.numLockKey);
            this.keysPanel.Controls.Add(this.key2D);
            this.keysPanel.Controls.Add(this.divideKey);
            this.keysPanel.Controls.Add(this.key2C);
            this.keysPanel.Controls.Add(this.multiplyKey);
            this.keysPanel.Controls.Add(this.enterKey);
            this.keysPanel.Controls.Add(this.subtractKey);
            this.keysPanel.Controls.Add(this.capsLockKey);
            this.keysPanel.Controls.Add(this.num7Key);
            this.keysPanel.Controls.Add(this.key28);
            this.keysPanel.Controls.Add(this.num8Key);
            this.keysPanel.Controls.Add(this.key27);
            this.keysPanel.Controls.Add(this.num9Key);
            this.keysPanel.Controls.Add(this.key26);
            this.keysPanel.Controls.Add(this.num4key);
            this.keysPanel.Controls.Add(this.key25);
            this.keysPanel.Controls.Add(this.num5key);
            this.keysPanel.Controls.Add(this.key24);
            this.keysPanel.Controls.Add(this.num6key);
            this.keysPanel.Controls.Add(this.key23);
            this.keysPanel.Controls.Add(this.num1Key);
            this.keysPanel.Controls.Add(this.key22);
            this.keysPanel.Controls.Add(this.num2Key);
            this.keysPanel.Controls.Add(this.key21);
            this.keysPanel.Controls.Add(this.num3Key);
            this.keysPanel.Controls.Add(this.key20);
            this.keysPanel.Controls.Add(this.decimalKey);
            this.keysPanel.Controls.Add(this.key1F);
            this.keysPanel.Controls.Add(this.num0Key);
            this.keysPanel.Controls.Add(this.key1E);
            this.keysPanel.Controls.Add(this.addKey);
            this.keysPanel.Controls.Add(this.keyB);
            this.keysPanel.Controls.Add(this.numEnterKey);
            this.keysPanel.Controls.Add(this.key2B);
            this.keysPanel.Controls.Add(this.key29);
            this.keysPanel.Controls.Add(this.key1B);
            this.keysPanel.Controls.Add(this.key2);
            this.keysPanel.Controls.Add(this.key1A);
            this.keysPanel.Controls.Add(this.key3);
            this.keysPanel.Controls.Add(this.key19);
            this.keysPanel.Controls.Add(this.key4);
            this.keysPanel.Controls.Add(this.key18);
            this.keysPanel.Controls.Add(this.key5);
            this.keysPanel.Controls.Add(this.key17);
            this.keysPanel.Controls.Add(this.key6);
            this.keysPanel.Controls.Add(this.key16);
            this.keysPanel.Controls.Add(this.key7);
            this.keysPanel.Controls.Add(this.key15);
            this.keysPanel.Controls.Add(this.key8);
            this.keysPanel.Controls.Add(this.key14);
            this.keysPanel.Controls.Add(this.key9);
            this.keysPanel.Controls.Add(this.key13);
            this.keysPanel.Controls.Add(this.keyA);
            this.keysPanel.Controls.Add(this.key12);
            this.keysPanel.Controls.Add(this.keyC);
            this.keysPanel.Controls.Add(this.key11);
            this.keysPanel.Controls.Add(this.keyD);
            this.keysPanel.Controls.Add(this.key10);
            this.keysPanel.Controls.Add(this.backSpaceKey);
            this.keysPanel.Controls.Add(this.tabKey);
            this.keysPanel.Location = new System.Drawing.Point(12, 12);
            this.keysPanel.Name = "keysPanel";
            this.keysPanel.Size = new System.Drawing.Size(1247, 373);
            this.keysPanel.TabIndex = 120;
            this.keysPanel.Tag = "";
            // 
            // layoutLabel
            // 
            this.layoutLabel.AutoSize = true;
            this.layoutLabel.Location = new System.Drawing.Point(1015, 27);
            this.layoutLabel.Name = "layoutLabel";
            this.layoutLabel.Size = new System.Drawing.Size(47, 15);
            this.layoutLabel.TabIndex = 118;
            this.layoutLabel.Text = "`Layout";
            // 
            // modeFlowLayoutPanel
            // 
            this.modeFlowLayoutPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.modeFlowLayoutPanel.Controls.Add(this.modeGroupBox);
            this.modeFlowLayoutPanel.Controls.Add(this.modifiersGroupBox);
            this.modeFlowLayoutPanel.Controls.Add(this.displayGroupBox);
            this.modeFlowLayoutPanel.Controls.Add(this.chordBox);
            this.modeFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.modeFlowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.modeFlowLayoutPanel.Location = new System.Drawing.Point(3, 3);
            this.modeFlowLayoutPanel.Name = "modeFlowLayoutPanel";
            this.modeFlowLayoutPanel.Size = new System.Drawing.Size(977, 90);
            this.modeFlowLayoutPanel.TabIndex = 121;
            // 
            // chordBox
            // 
            this.chordBox.Controls.Add(this.chordComboBox);
            this.chordBox.Location = new System.Drawing.Point(162, 3);
            this.chordBox.Margin = new System.Windows.Forms.Padding(3, 3, 10, 3);
            this.chordBox.Name = "chordBox";
            this.chordBox.Size = new System.Drawing.Size(243, 81);
            this.chordBox.TabIndex = 151;
            this.chordBox.TabStop = false;
            this.chordBox.Text = "Chord";
            // 
            // chordComboBox
            // 
            this.chordComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.chordComboBox.FormattingEnabled = true;
            this.chordComboBox.Items.AddRange(new object[] {
            "None"});
            this.chordComboBox.Location = new System.Drawing.Point(6, 22);
            this.chordComboBox.Name = "chordComboBox";
            this.chordComboBox.Size = new System.Drawing.Size(225, 21);
            this.chordComboBox.TabIndex = 150;
            this.chordComboBox.SelectedIndexChanged += new System.EventHandler(this.ChordIndexChanged);
            // 
            // bottomTableLayoutPanel
            // 
            this.bottomTableLayoutPanel.ColumnCount = 1;
            this.bottomTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.bottomTableLayoutPanel.Controls.Add(this.modeFlowLayoutPanel, 0, 0);
            this.bottomTableLayoutPanel.Location = new System.Drawing.Point(248, 392);
            this.bottomTableLayoutPanel.Name = "bottomTableLayoutPanel";
            this.bottomTableLayoutPanel.RowCount = 1;
            this.bottomTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.bottomTableLayoutPanel.Size = new System.Drawing.Size(983, 96);
            this.bottomTableLayoutPanel.TabIndex = 122;
            // 
            // KeyboardPicture
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1269, 510);
            this.Controls.Add(this.helpPictureBox);
            this.Controls.Add(this.bottomTableLayoutPanel);
            this.Controls.Add(this.keysPanel);
            this.Controls.Add(this.aplLegendLabel);
            this.Controls.Add(this.aplLegendPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "KeyboardPicture";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Keyboard Map";
            this.Activated += new System.EventHandler(this.KeyboardPicture_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.KeyboardPicture_FormClosing);
            this.InputLanguageChanged += new System.Windows.Forms.InputLanguageChangedEventHandler(this.KeyboardPicture_InputLanguageChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyCapture_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyCapture_KeyUp);
            this.displayGroupBox.ResumeLayout(false);
            this.displayGroupBox.PerformLayout();
            this.displayTable.ResumeLayout(false);
            this.displayTable.PerformLayout();
            this.modifiersGroupBox.ResumeLayout(false);
            this.modifiersGroupBox.PerformLayout();
            this.modifiersTable.ResumeLayout(false);
            this.modifiersTable.PerformLayout();
            this.modeGroupBox.ResumeLayout(false);
            this.modeGroupBox.PerformLayout();
            this.modeTable.ResumeLayout(false);
            this.modeTable.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.helpPictureBox)).EndInit();
            this.helpContextMenuStrip.ResumeLayout(false);
            this.aplLegendPanel.ResumeLayout(false);
            this.keysPanel.ResumeLayout(false);
            this.keysPanel.PerformLayout();
            this.modeFlowLayoutPanel.ResumeLayout(false);
            this.modeFlowLayoutPanel.PerformLayout();
            this.chordBox.ResumeLayout(false);
            this.bottomTableLayoutPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label escapeKey;
        private System.Windows.Forms.Label f1Key;
        private System.Windows.Forms.Label f2Key;
        private System.Windows.Forms.Label f3Key;
        private System.Windows.Forms.Label f7Key;
        private System.Windows.Forms.Label f6Key;
        private System.Windows.Forms.Label f5Key;
        private System.Windows.Forms.Label f4Key;
        private System.Windows.Forms.Label f9Key;
        private System.Windows.Forms.Label f8Key;
        private System.Windows.Forms.Label f11Key;
        private System.Windows.Forms.Label f10Key;
        private System.Windows.Forms.Label f12Key;
        private System.Windows.Forms.Label prtScnKey;
        private System.Windows.Forms.Label scrollLockKey;
        private System.Windows.Forms.Label pauseKey;
        private System.Windows.Forms.Label pageUpKey;
        private System.Windows.Forms.Label homeKey;
        private System.Windows.Forms.Label insertKey;
        private System.Windows.Forms.Label pageDownKey;
        private System.Windows.Forms.Label endKey;
        private System.Windows.Forms.Label deleteKey;
        private System.Windows.Forms.Label upKey;
        private System.Windows.Forms.Label rightKey;
        private System.Windows.Forms.Label downKey;
        private System.Windows.Forms.Label leftKey;
        private System.Windows.Forms.Label subtractKey;
        private System.Windows.Forms.Label multiplyKey;
        private System.Windows.Forms.Label divideKey;
        private System.Windows.Forms.Label numLockKey;
        private System.Windows.Forms.Label num9Key;
        private System.Windows.Forms.Label num8Key;
        private System.Windows.Forms.Label num7Key;
        private System.Windows.Forms.Label num6key;
        private System.Windows.Forms.Label num5key;
        private System.Windows.Forms.Label num4key;
        private System.Windows.Forms.Label num3Key;
        private System.Windows.Forms.Label num2Key;
        private System.Windows.Forms.Label num1Key;
        private System.Windows.Forms.Label decimalKey;
        private System.Windows.Forms.Label num0Key;
        private System.Windows.Forms.Label addKey;
        private System.Windows.Forms.Label numEnterKey;
        private System.Windows.Forms.Label key29;
        private System.Windows.Forms.Label key2;
        private System.Windows.Forms.Label key3;
        private System.Windows.Forms.Label key4;
        private System.Windows.Forms.Label key5;
        private System.Windows.Forms.Label key6;
        private System.Windows.Forms.Label key7;
        private System.Windows.Forms.Label key8;
        private System.Windows.Forms.Label key9;
        private System.Windows.Forms.Label keyA;
        private System.Windows.Forms.Label keyC;
        private System.Windows.Forms.Label keyD;
        private System.Windows.Forms.Label backSpaceKey;
        private System.Windows.Forms.Label tabKey;
        private System.Windows.Forms.Label key10;
        private System.Windows.Forms.Label key11;
        private System.Windows.Forms.Label key12;
        private System.Windows.Forms.Label key13;
        private System.Windows.Forms.Label key14;
        private System.Windows.Forms.Label key15;
        private System.Windows.Forms.Label key16;
        private System.Windows.Forms.Label key17;
        private System.Windows.Forms.Label key18;
        private System.Windows.Forms.Label key19;
        private System.Windows.Forms.Label key1A;
        private System.Windows.Forms.Label key1B;
        private System.Windows.Forms.Label key2B;
        private System.Windows.Forms.Label keyB;
        private System.Windows.Forms.Label key28;
        private System.Windows.Forms.Label key27;
        private System.Windows.Forms.Label key26;
        private System.Windows.Forms.Label key25;
        private System.Windows.Forms.Label key24;
        private System.Windows.Forms.Label key23;
        private System.Windows.Forms.Label key22;
        private System.Windows.Forms.Label key21;
        private System.Windows.Forms.Label key20;
        private System.Windows.Forms.Label key1F;
        private System.Windows.Forms.Label key1E;
        private System.Windows.Forms.Label capsLockKey;
        private System.Windows.Forms.Label enterKey;
        private System.Windows.Forms.Label key35;
        private System.Windows.Forms.Label key34;
        private System.Windows.Forms.Label key33;
        private System.Windows.Forms.Label key32;
        private System.Windows.Forms.Label key31;
        private System.Windows.Forms.Label key30;
        private System.Windows.Forms.Label key2F;
        private System.Windows.Forms.Label key2E;
        private System.Windows.Forms.Label key2D;
        private System.Windows.Forms.Label key2C;
        private System.Windows.Forms.Label leftShiftKey;
        private System.Windows.Forms.Label rightShiftKey;
        private System.Windows.Forms.Label leftWinKey;
        private System.Windows.Forms.Label leftAltKey;
        private System.Windows.Forms.Label rightAltKey;
        private System.Windows.Forms.Label appsKey;
        private System.Windows.Forms.Label rightCtrlKey;
        private System.Windows.Forms.Label leftCtrlKey;
        private System.Windows.Forms.Label spaceBar;
        private System.Windows.Forms.RadioButton labelsRadioButton;
        private System.Windows.Forms.RadioButton keyNamesRadioButton;
        private System.Windows.Forms.RadioButton definitionsRadioButton;
        private System.Windows.Forms.CheckBox numLockCheckBox;
        private System.Windows.Forms.CheckBox shiftCheckBox;
        private System.Windows.Forms.CheckBox ctrlCheckBox;
        private System.Windows.Forms.CheckBox altCheckBox;
        private System.Windows.Forms.GroupBox displayGroupBox;
        private System.Windows.Forms.GroupBox modifiersGroupBox;
        private System.Windows.Forms.Label rightWinKey;
        private System.Windows.Forms.Label noteLabel;
        private System.Windows.Forms.GroupBox modeGroupBox;
        private System.Windows.Forms.Label key56;
        private System.Windows.Forms.Label nativeNameLabel;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.CheckBox scrollLockCheckBox;
        private System.Windows.Forms.FlowLayoutPanel aplLegendPanel;
        private System.Windows.Forms.Label aplShiftLabel;
        private System.Windows.Forms.Label aplCtrlShiftLabel;
        private System.Windows.Forms.Label aplNormalLabel;
        private System.Windows.Forms.Label aplCtrlLabel;
        private System.Windows.Forms.Label aplLegendLabel;
        private System.Windows.Forms.Panel keysPanel;
        private System.Windows.Forms.FlowLayoutPanel displayLayoutPanel;
        private System.Windows.Forms.FlowLayoutPanel modifiersLayoutPanel;
        private System.Windows.Forms.FlowLayoutPanel modeLayoutPanel;
        private System.Windows.Forms.FlowLayoutPanel modeFlowLayoutPanel;
        private System.Windows.Forms.TableLayoutPanel bottomTableLayoutPanel;
        private System.Windows.Forms.RadioButton scanCodesRadioButton;
        private System.Windows.Forms.CheckBox nvtModeCheckBox;
        private System.Windows.Forms.CheckBox mode3270CheckBox;
        private System.Windows.Forms.TableLayoutPanel modifiersTable;
        private System.Windows.Forms.TableLayoutPanel displayTable;
        private System.Windows.Forms.TableLayoutPanel modeTable;
        private System.Windows.Forms.GroupBox chordBox;
        private System.Windows.Forms.ComboBox chordComboBox;
        private System.Windows.Forms.Label layoutLabel;
        private System.Windows.Forms.PictureBox helpPictureBox;
        private System.Windows.Forms.ContextMenuStrip helpContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem displayHelpInBrowserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startTourToolStripMenuItem;
    }
}